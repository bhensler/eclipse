/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.community.*;
import com.lotus.sametime.commui.*;

/**
 * Resolve Sample using the resolve panel.
 */
public class ResolveApplet extends Applet 
  implements LoginListener, ResolveViewListener
{
  /**
   * Our session.
   */
  private STSession m_session;
      
  /**
   * Text area for displaying messages.
   */
  private TextArea m_textArea;
      
  /**
   * The entry point for the applet. 
   */
  public void init()
  {
    try
    {
      // generate a new session with a unique name
      m_session = new STSession("Resolve Applet " + this);
                      
      // Call the session to load all available components 
      m_session.loadAllComponents();
      m_session.start();
                      
      setLayout(new BorderLayout());
      ResolvePanel resolvePanel = new ResolvePanel(m_session);
      add(resolvePanel, BorderLayout.CENTER);
                      
      //register a listener to receive notifications about user 
      //resolved events. 
      resolvePanel.addResolveViewListener(this);
                      
      m_textArea = new TextArea();
      add(m_textArea, BorderLayout.SOUTH);
                      
      // login to the community
      login();
    }
    catch(DuplicateObjectException e)
    {
      // This exception is thrown if an STSession with the same 
      // name has already been created.
      e.printStackTrace();
    }                 
  }
        
  /**
   * Login to the community using the user name and password 
   * parameters from the html.
   */
  private void login()
  {
    // get a reference to the community service. We use the session 
    // object which contains a reference to all the components that 
    // were loaded to get a reference to the community service. 
    CommunityService comm = (CommunityService) 
                 m_session.getCompApi(CommunityService.COMP_NAME);
              
    // register a listener to the login/logout events.
    comm.addLoginListener(this);
              
    // login to the community
    comm.loginByPassword(getCodeBase().getHost(),
                          getParameter("loginName"),
                          getParameter("password"));              
  }
    
  /**
   * Login event. 
   */
  public void loggedIn(LoginEvent event)
  {
    String msg  = "Logged In";
    m_textArea.setText(msg);
  }
      
  /**
   * Logout event
   */
  public void loggedOut(LoginEvent event)
  {
    String msg  = "Logged Out";
    m_textArea.setText(msg);
  }
      
  /**
   * Returns the applet's insets. Creates 5 pixel margin around 
   * the applet. 
   */
  public Insets getInsets()
  {
    return new Insets(5, 5, 5, 5);
  }

  /**
   * Notification of a successful resolve operation.
   */
  public void resolved(ResolveViewEvent event)
  {
    String msg = "**** Resolved ****\n";
    msg += event.getResolvedName() + " : " + 
           event.getUser().getName();
    m_textArea.setText(msg);
  }

  /**
   * Notification of a failed resolve operation.
   */
  public void resolveFailed(ResolveViewEvent event)
  {
    String msg = "**** Resolved Failed****\n";
    msg += event.getResolvedName() + ", Reason:" + 
           Integer.toHexString(event.getReason());
    m_textArea.setText(msg);
  }

  /**
   * Applet destroyed. Logout of Sametime.
   */
  public void destroy()
  {
    CommunityService comm = (CommunityService) 
             m_session.getCompApi(CommunityService.COMP_NAME);
    comm.logout();
            
    m_session.stop();
    m_session.unloadSession();            
  }
}
 
