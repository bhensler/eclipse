/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.Vector;
import java.util.StringTokenizer;

import com.lotus.sametime.chatui.*;
import com.lotus.sametime.core.comparch.*;
import com.lotus.sametime.core.types.STUser;
import com.lotus.sametime.community.*;
import com.lotus.sametime.commui.*;
import com.lotus.sametime.core.constants.MeetingTypes;

/**
 * A sample of the chat ui component. 
 */
public class ChatUIApplet extends Applet implements LoginListener, 
                                                    MeetingListener, 
                                                    UrlClickListener,
                                                    ActionListener,
                                                    CommUIListener
{
  /**
   * The session.
   */
  private STSession m_session;
      
  /**
   * The chat ui component.
   */
  private ChatUI m_chatUI;
      
  /**
   * The community ui component.
   */
  private CommUI m_commUI;
      
  /**
   * The number of names that are waiting to be resolved.
   */
  private int m_namesToResolve;
      
  /**
   * The list of resolved meeting users.
   */
  private Vector m_meetingUsers = new Vector();
                                                 
  /**
   * The 'meeting type' choice.
   */
  private Choice m_chType;
      
  /**
   * The user names text field.
   */
  private TextField m_tfInvitees;
      
  /**
   * The 'send' button.
   */
  private Button m_btnSend;
      
  /**
   * The 'Show invite dialog' check box.
   */
  private Checkbox m_cbInviteDlg;
      
      
  /**
   * Applet life cycle
   */
  public void init()
  {
    // Create a session of components.
    try
    {
      m_session = new STSession("ChatUIApplet");
      m_session.loadAllComponents();
      m_session.start();
    }
    catch(DuplicateObjectException e)
    {
      e.printStackTrace();
    }
              
    initializeLayout();
              
    // Login to the community.
    String serverName = getCodeBase().getHost().toString();
    String loginName  = getParameter("loginName");
    String password   = getParameter("password");
              
              
    CommunityService comm = (CommunityService)m_session.getCompApi
      (CommunityService.COMP_NAME);
    comm.addLoginListener(this);
    comm.loginByPassword(serverName, loginName, password);
              
    m_chatUI = (ChatUI)m_session.getCompApi(ChatUI.COMP_NAME);
    m_chatUI.addUrlClickListener(this);
    m_chatUI.addMeetingListener(this);
              
    m_commUI = (CommUI)m_session.getCompApi(CommUI.COMP_NAME);
    m_commUI.addCommUIListener(this);
  }
      
  /**
   * Applet destroyed. Stop and unload the session.
   */
  public void destroy()
  {
    CommunityService comm = (CommunityService) 
            m_session.getCompApi(CommunityService.COMP_NAME);

    comm.logout();  
    m_session.stop();
    m_session.unloadSession();
  }
      
  //
  // Login Listener.
  //
      
  /**
   * Logged in to the community.
   */
  public void loggedIn(LoginEvent event)
  {
    System.out.println("Applet: LOGGED IN");
    m_btnSend.setEnabled(true);
  }
      
  /**
   * Logged out of the community.
   */
  public void loggedOut(LoginEvent event)
  {
    System.out.println("SAMPLE: LOGGED OUT. REASON=" + 
                       event.getReason());
    m_btnSend.setEnabled(false);
  }
      
  //
  // Action Listener.
  //
      
  /**
   * Send button was clicked.
   */
  public void actionPerformed(ActionEvent p1)
  {
    String[] userNames = breakString(m_tfInvitees.getText(), ",");
    if (userNames == null || userNames.length == 0)
    {
      return;
    }
              
    // Disable the send button until wer'e finished.
    m_btnSend.setEnabled(false);
              
    // Try to resolve the names.
    m_namesToResolve = userNames.length;
    for (int i=0; i < m_namesToResolve; i++)
    {
      m_commUI.resolve(userNames[i]);
    }
  }

  //
  // CommuiListener.
  // 
  /**
   * Resolve request succeded.
   */
  public void resolved(CommUIEvent event)
  {
    STUser resolved = event.getUser();
    m_meetingUsers.addElement(resolved);
              
    if (--m_namesToResolve == 0)
    {
      createMeeting();
    }
  }

  /**
   * Resolve request failed.
   */
  public void resolveFailed(CommUIEvent event)
  {
    if (--m_namesToResolve == 0)
    {
      createMeeting();
    }
  }
      
  /**
   * All names resolved. Create the meeting.
   */
  private void createMeeting()
  {
    m_btnSend.setEnabled(true);
              
    String meetingType = m_chType.getSelectedItem();
              
    // Check if it is an 1on1 instant message.
    if ((meetingType == "Chat") && m_meetingUsers.size() == 1)
    {
      STUser imPartner = (STUser)m_meetingUsers.firstElement();
      m_chatUI.create1On1ChatById(imPartner);    
                        
      m_meetingUsers.removeAllElements();
      return;
    }
              
    // Create the meeting type according to the selected string.
    MeetingTypes type = null;
    if (meetingType == "Chat")
    {
      type = MeetingTypes.ST_CHAT_MEETING;
    }
    else if (meetingType == "Audio")
    {
      type = MeetingTypes.ST_AUDIO_MEETING;
    }
    else if (meetingType == "Video")
    {
      type = MeetingTypes.ST_VIDEO_MEETING;
    }
    else if (meetingType == "Share")
    {
      type = MeetingTypes.ST_SHARE_MEETING;
    }
    else if (meetingType == "Collaboration")
    {
      type = MeetingTypes.ST_COLLABORATION_MEETING;
    }
              
    STUser[] invitees = new STUser[m_meetingUsers.size()];
    m_meetingUsers.copyInto(invitees);
              
    boolean showInviteDlg = m_cbInviteDlg.getState();
              
    m_chatUI.createMeeting(type, "", "", showInviteDlg, invitees);
    m_meetingUsers.removeAllElements();
  }
      
  //
  // Meeting Listener.
  //
      
  /**
   * Open the meeting room client to participate in a meeting. 
   * This event is received as a result of this user initiating 
   * a meeting or being invited to join a meeting by a different 
   * user.
   */
  public void launchMeeting(MeetingInfo meetingInfo, URL url)
  {
    getAppletContext().showDocument(url, 
                   meetingInfo.getDisplayName());
  }
      
      
  /**
   * An error has occured during a meeting creation. 
   */
  public void meetingCreationFailed(MeetingInfo meetingInfo, 
                                    int reason)
  {
    System.err.println("Failed to create the meeting: " + reason);
  }

  //
  // Url Click Listener.
  //
      
  /**
   * Url was clicked. Open it.
   */
  public void urlClicked(UrlClickEvent event)
  {
    URL url;
    String urlString = event.getURL();
    try
    {
      url = new URL(urlString);    
    }
    catch(MalformedURLException e)
    {
      System.err.println("URL Clicked: MALFORMED URL");
      return;
    }
              
    getAppletContext().showDocument(url);                             
  }
      
  //
  // Helpers.
  //
      
  /**
   * Set up the ui components.
   */
  void initializeLayout()
  {
    m_chType = new Choice();
    m_chType.add("Chat");
    m_chType.add("Audio");
    m_chType.add("Video");
    m_chType.add("Share");
    m_chType.add("Collaboration");
              
    Panel p = new Panel(new GridLayout(3,1));
          
    Panel p1 = new Panel();
    p1.add(m_btnSend = new Button("Send"));
    p1.add(m_cbInviteDlg = new Checkbox("Show Invite Dialog", true));
              
    Panel p2 = new Panel(new GridLayout(3,1));
    p2.add(new Label("Meeting type:"));
    p2.add(m_chType);
    p2.add(p1);
              
    Panel p3 = new Panel (new BorderLayout());
    p3.add(new Label("Invitees names (divided by ,):"),
           BorderLayout.CENTER);
    p3.add(m_tfInvitees = new TextField(),BorderLayout.SOUTH );
              
    p.add(p3);
    p.add(p2);
    p.add(p1);
              
    add(p);
             
    m_btnSend.addActionListener(this);
              
    // Enable sending only when we are logged in.
    m_btnSend.setEnabled(false);
  }

  /**
   * Break a string into an array of smaller strings, based on a given
   * separator char.
   */
  protected String[] breakString(String toBreak, String separator)
  {
    String[] result = null;
    if (toBreak != null && !toBreak.equalsIgnoreCase("")) {
      if (separator == null || separator.equalsIgnoreCase("")) {
        result = new String[1];
        result[0] = toBreak;
      }
      else {
        StringTokenizer stk = new StringTokenizer(toBreak, 
                                                  separator);
        result = new String[stk.countTokens()];
        for (int i = 0; i < result.length && stk.hasMoreTokens(); 
             i++)
          result[i] = stk.nextToken();
      }
    }
    return result;
  }
}
