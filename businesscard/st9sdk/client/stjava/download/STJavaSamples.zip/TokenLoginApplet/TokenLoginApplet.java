/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.applet.*;
import java.util.*;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.types.STUser;
import com.lotus.sametime.community.*;
import com.lotus.sametime.awarenessui.list.AwarenessList;

/**
 * Sample applet that logs in to a Sametime server using a token.
 */
public class TokenLoginApplet extends Applet
    implements LoginListener
{
  private STSession m_session;
  private CommunityService m_comm;    
  private AwarenessList m_awarenessList;
    
  /**
   * Applet initalized. Create the session, load all components,
   * start the session and then login.
   */
  public void init()
  {
    try
    {
      m_session = new STSession("TokenLoginApplet " + this);
      m_session.loadAllComponents();
      m_session.start();
            
      setLayout(new BorderLayout());
      m_awarenessList = new AwarenessList(m_session, false);
      add(m_awarenessList, BorderLayout.CENTER);

      login();
    }
    catch(DuplicateObjectException e)
    {
      e.printStackTrace();
    }
  }
    
  /**
   * Login to the community using the user name and token 
   * parameters from the html.
   */
  private void login()
  {
    m_comm = (CommunityService)
        m_session.getCompApi(CommunityService.COMP_NAME);
    m_comm.addLoginListener(this);     
    m_comm.loginByToken(getCodeBase().getHost(),
                         getParameter("loginName"),
                         getParameter("token"));     
  }
    
  /**
   * Logged in event. Print logged in msg to console.
   * Add the user to the awareness list. 
   */
  public void loggedIn(LoginEvent event)
  {
    System.out.println("Logged In");
    m_awarenessList.addUser(
                    (STUser)event.getLogin().getMyUserInstance());
  }

  /**
   * Logged out event. Print logged out msg to console. Leave default
   * behavior which will display a dialog box. 
   */
  public void loggedOut(LoginEvent event)
  {
    System.out.println("Logged Out");
  }

  /**
   * Applet destroyed. Logout, stop and unload the session.
   */
  public void destroy()
  {
    m_comm.logout();
    m_session.stop();
    m_session.unloadSession();
  }
}
