/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.util.Calendar;
import java.util.Random;

import com.lotus.sametime.chat.MeetingInfo;
import com.lotus.sametime.chat.invitation.*;
import com.lotus.sametime.community.CommunityService;
import com.lotus.sametime.community.LoginEvent;
import com.lotus.sametime.community.LoginListener;
import com.lotus.sametime.core.comparch.*;
import com.lotus.sametime.core.constants.EncLevel;
import com.lotus.sametime.core.constants.MeetingTypes;
import com.lotus.sametime.core.types.STUser;
import com.lotus.sametime.lookup.*;
import com.lotus.sametime.places.PlacesConstants;

/**
 * This sample will login, resolve the specified user and invite them to an n-way chat.
 *
 * NOTE: This sample assumes the specified user has a unique name and is online.
 *
 * NOTE: This sample block waits on things like login, service available events, lookup, etc. just for simplicity.
 *
 * Once accepted, it will create an NwayChatSample based on the invitation.
 */
public class NwayInviter implements LoginListener, LookupServiceListener, ResolveListener
{
    private STSession m_session = null;
    private CommunityService m_commSvc = null;
    private String m_host = "";
    private String m_user = "";
    private String m_password = "";
    private boolean m_loggedIn = false;
    private boolean m_lookupSvcAvailable = false;
    private STUser m_userToInvite = null;

    public NwayInviter(String host, String user, String password, String userToInvite)
    {
        m_host = host;
        m_user = user;
        m_password = password;

        try
        {
            m_session = new STSession("NwayInviter " + this);
            m_session.loadSemanticComponents();
            m_session.start();

            // Get a handle to the LookupService
            LookupService lookupSvc = (LookupService) m_session.getCompApi(LookupService.COMP_NAME);
            lookupSvc.addLookupServiceListener(this);

            login();
            while (!m_loggedIn)
            {
                System.out.print("");
            }

            // Wait until the LookupService is available.
            while (!m_lookupSvcAvailable)
            {
                System.out.print("");
            }

            // Create a resolver so we can resolve the user we are inviting
            Resolver resolver = lookupSvc.createResolver(true, true, true, false);
            resolver.addResolveListener(this);
            resolver.resolve(userToInvite);

            // Wait for the user to be resolved
            while (m_userToInvite == null)
            {
                System.out.print("");
            }

            sendInvitation();
        }
        catch(DuplicateObjectException e)
        {
            e.printStackTrace();
        }
    }

    private void login()
    {
    	m_commSvc = (CommunityService) m_session.getCompApi(CommunityService.COMP_NAME);
    	m_commSvc.addLoginListener(this);
    	m_commSvc.loginByPassword(m_host, m_user, m_password.toCharArray());
    }

    public void loggedIn(LoginEvent event)
    {
        m_loggedIn = true;
        System.out.println("Logged In at: " + Calendar.getInstance().getTime().toString());
    }

    public void loggedOut(LoginEvent event)
    {
        m_loggedIn = false;
        System.out.println("Logged Out: 0x" + Integer.toHexString(event.getReason()) + " at: " + Calendar.getInstance().getTime().toString());
    }

    public void sendInvitation()
    {
    	System.out.println("Inviting " + m_userToInvite.getDisplayName() + " to an n-way meeting");

    	// Generate a random place id
    	Random random = new Random();
		int randomPortion = Math.abs(random.nextInt());
		String placeName = "stNwayChat" + randomPortion;
		String chatDisplayName = "ST SDK Sample N-Way Chat";
		String invitationText = "Please join my sample N-Way chat.";

        InvitationManager invitationManager = new InvitationManager(m_session);
        Inviter inviter = invitationManager.createInviter();
    	MeetingInfo meetingInfo = new MeetingInfo(MeetingTypes.ST_CHAT_MEETING, chatDisplayName, EncLevel.ENC_LEVEL_RC2_40, placeName, "", "");
        inviter.invite(meetingInfo, invitationText, new STUser[] { m_userToInvite }, true);

    	// Create a new instance of the NwayChatSample based on the information in this invitation.
    	// Note: In this case we want to join an existing place.
    	new NwayChatSample(m_session,
    			placeName,
    			chatDisplayName,
    			"",
    			PlacesConstants.PLACE_CREATION_CREATE);
    }

	public void serviceAvailable(LookupEvent evt)
	{
		m_lookupSvcAvailable = true;
	}

    public void resolved(ResolveEvent event)
    {
    	m_userToInvite = (STUser) event.getResolved();
    }

    public void resolveConflict(ResolveEvent event)
    {
    	// Ignore conflicts for this sample as we only are using unique names
    }

    public void resolveFailed(ResolveEvent event)
    {
    	System.out.println("Failed to resolve user - reason: 0x" + Integer.toHexString(event.getReason()));
    }

	public static void main(String[] args)
	{
    	if (args.length < 3)
    	{
            System.out.println("Wrong number of arguments.  Please supply servername, user amd password");
            System.out.println("Example: java NwayInviter sametime.acme.com testUser testPassword userToInvite");
        }
        else
        {
            String server = args[0];
            String user = args[1];
            String pwd = args[2];
            String userToInvite = args[3];
        	new NwayInviter(server, user, pwd, userToInvite);
        }
	}
}