/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.util.*;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.constants.*;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.community.*;
import com.lotus.sametime.awareness.*;
import com.lotus.sametime.commui.*;
import com.lotus.sametime.guiutils.chat.ChatArea;

public class AwarenessApplet extends Applet 
  implements LoginListener,CommUIListener, AwarenessServiceListener,
             StatusListener, ActionListener
							
{
  private STSession m_session;
  private CommunityService m_comm;
  private CommUI m_commUiService;
  private AwarenessService m_awareness;
  private WatchList m_watchList;
  	
  private String m_myName ="";
  private TextField m_watchName = new TextField();
  private Button m_addBtn = new Button("Add");
  private Font m_font = new Font("Dialog", Font.PLAIN, 12);
  private ChatArea m_transcript = new ChatArea(150, m_font, 15);
  	
  public void init()
  {
    try
    {
      m_session = new STSession("ImApplet" + this);
      m_session.loadAllComponents();			
    }
    catch(DuplicateObjectException e)
    {
      e.printStackTrace();
    }
              
    m_session.start();
      			
    initLayout();
    login();
  }
      
  /**
   * set the applet layout 
   */
  private void initLayout()
  {
    setLayout(new BorderLayout(0,0));
    Font labelFont = new Font("Dialog",14,Font.PLAIN);
              
    Panel pnl = new Panel(new BorderLayout(0,0));
    pnl.add(new Label("Watch user name:"),BorderLayout.NORTH);
    pnl.add(m_watchName,BorderLayout.CENTER);
    pnl.add(m_addBtn,BorderLayout.EAST);
    m_addBtn.addActionListener(this);
              
    add(pnl,BorderLayout.NORTH );
    add(m_transcript,BorderLayout.CENTER);
    validate();
  }

  /**
   * Login to the community using the user name and password 
   * parameters from the html.
   */
  private void login()
  {
    m_comm = (CommunityService)
    m_session.getCompApi(CommunityService.COMP_NAME);
      		
    m_comm.addLoginListener(this);     
      		
    m_comm.loginByPassword(getCodeBase().getHost().toString(),
    getParameter("loginName"),
    getParameter("password"));     		
  }
      
  /**
   * Loggedin event receive only if loggedin successfully
   */
  public void loggedIn(LoginEvent event)
  {
    m_myName = 
        m_comm.getLogin().getMyUserInstance().getDisplayName();
    m_transcript.writeSeparator("Loggedin :"+m_myName, 
                                Color.green);
    m_awareness = (AwarenessService)
        m_session.getCompApi(AwarenessService.COMP_NAME);
    m_awareness.addAwarenessServiceListener(this);
              
    m_commUiService = (CommUI )
        m_session.getCompApi(CommUI.COMP_NAME);
    m_commUiService.addCommUIListener(this);
  }

  /**
   * Loggedin event receive only if loggedout 
   */
  public void loggedOut(LoginEvent event)
  {
    m_transcript.writeSeparator("Loggedout :"+m_myName, Color.green);
  }

  /**
   * if the send button was pressed take the name form the textField
   * and resolve for appropriate user
   */
  public void actionPerformed(ActionEvent event)
  {
    m_commUiService.resolve(m_watchName.getText());
  }
       
  /**
   * resolved event receive aftere you send request to resolve a name
   */
  public void resolved(CommUIEvent event)
  {
    m_watchList.addItem(event.getUser());
  }

  /**
   * resolveFailed event receive aftere you send request to resolve 
   * a name but no approrriate user was found.
   */
  public void resolveFailed(CommUIEvent event)
  {
    m_transcript.writeSeparator("resolve failed type another name" , 
                                Color.red);
  }

  /**
   * Indicates that the awareness service is currently available.
   */
  public void serviceAvailable(AwarenessServiceEvent event)
  {
    m_watchList = m_awareness.createWatchList();
    m_watchList.addStatusListener(this);
  }

  /**
   * Indicates that the awareness service is currently unavailable.
   */
  public void serviceUnavailable(AwarenessServiceEvent event)
  {
    m_transcript.writeSeparator("Awareness service unavailable" , 
                                Color.red);
  }

  /**
   * Indicates one or more users status' have changed.
   */
  public void userStatusChanged(StatusEvent event)
  {
    STWatchedUser[] users =(STWatchedUser[])event.getWatchedUsers();
    for(int i=0; i<users.length; i++)
    {
      STUserStatus userStatus = users[i].getStatus();
      String statusDescription = 
         users[i].getStatus().getStatusDescription();
      if (users[i].getStatus().getStatusType()== 0)
      {
        statusDescription= "user is offline";
      }
      String message = users[i].getDisplayName()+" : " + 
                       statusDescription;
      m_transcript.writeSeparator(message , Color.black);
    }
  }

  /**
   * Indicates the awareness service has cleared the list of users
   * in a Sametime group. Any UI displaying the online users of a 
   * Sametime group should remove these users accordingly.
   */
  public void groupCleared(StatusEvent event)
  {
    m_transcript.writeSeparator("group cleared" , Color.red);
  }
      
  public void destroy()
  {
    m_comm.logout();
    m_session.stop();
    m_session.unloadSession();
  }
}
