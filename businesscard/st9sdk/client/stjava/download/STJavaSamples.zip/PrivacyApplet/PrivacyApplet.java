/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.community.*;
import com.lotus.sametime.commui.*;

/**
 * Privacy Sample using the privacy panel.
 */
public class PrivacyApplet extends Applet 
  implements LoginListener, ActionListener, MyPrivacyListener
{
  /**
   * Our session.
   */
  private STSession m_session;
         	
  /**
   * Text area for displaying messages.
   */
  private TextArea m_textArea;
      
      
  /**
   * The Privacy Panel. 
   */
  private PrivacyPanel m_privacyPanel;
      
  /**
   * The entry point for the applet. 
   */
  public void init()
  {
    try
    {
      // generate a new session with a unique name
      m_session = new STSession("Privacy Applet " + this);
                      
      // Call the session to load all available components 
      m_session.loadAllComponents();
      m_session.start();
                      
      //Create the UI components which include the privacy panel, 
      //submit button and the text area for displaying privacy 
      //information.
      setLayout(new BorderLayout(0, 10));
      Panel upperPanel = new Panel(new BorderLayout());
      m_privacyPanel = new PrivacyPanel(m_session);
      upperPanel.add(m_privacyPanel, BorderLayout.CENTER);
                      
      Panel btnsPanel = new Panel(new BorderLayout(0, 10));
      Button submitList = new Button("SubmitList");
      submitList.addActionListener(this);
                      
      btnsPanel.add(submitList, BorderLayout.CENTER);
      upperPanel.add(btnsPanel, BorderLayout.SOUTH);
      add(upperPanel, BorderLayout.CENTER);            
                      
      m_textArea = new TextArea();
      add(m_textArea, BorderLayout.SOUTH);
                                  
      // login to the community
      login();
    }
    catch(DuplicateObjectException e)
    {
      // This exception is thrown if an STSession with the same 
      // name has already been created.
      e.printStackTrace();
    }                 
  }
        
  /**
   * Login to the community using the user name and password 
   * parameters from the html.
   */
  private void login()
  {
    // get a reference to the community service. We use the session 
    // object which contains a reference to all the components that 
    // were loaded to get a reference to the community service. 
    CommunityService comm = (CommunityService) 
              m_session.getCompApi(CommunityService.COMP_NAME);
              
    // register a listener to the login/logout events.
    comm.addLoginListener(this);
              
    // login to the community
    comm.loginByPassword(getCodeBase().getHost(),
                          getParameter("loginName"),
                          getParameter("password"));
  }

  /**
   * Login event. 
   */
  public void loggedIn(LoginEvent event)
  {
    // register a listener to privacy change evnets. 
    event.getLogin().addMyPrivacyListener(this);        
              
    String msg  = "Logged In";
    m_textArea.setText(msg);
  }
      
  /**
   * Logout event
   */
  public void loggedOut(LoginEvent event)
  {
    String msg  = "Logged Out";
    m_textArea.setText(msg);
  }
       
  /**
   * Action Performed. The button was clicked open the dialog. 
   */
  public void actionPerformed(ActionEvent p1)
  {
    m_privacyPanel.submit();
  }
  
  /**
   * Returns the applet's insets. Creates 5 pixel margin around 
   * the applet. 
   */
  public Insets getInsets()
  {
    return new Insets(5, 5, 5, 5);
  }
      
  /**
   * My privacy settings changed. 
   */
  public void myPrivacyChanged(MyPrivacyEvent event)
  {
    String msg  = "**** Users in my Privacy List ****\n";
    Enumeration e =  event.getPrivacyList().elements();
              
    while(e.hasMoreElements())
    {
      msg += ((STUser) e.nextElement()).getName() + "\n";
    }
              
    msg += "**** End of List ****\n";
              
    m_textArea.setText(msg);
  }

  /**
   * Change to my privacy settings were denied. 
   */
  public void changeMyPrivacyDenied(MyPrivacyEvent event)
  {
    String msg  = "**** Privacy Settings Denied ****\n";
    m_textArea.setText(msg);
  }
            
  /**
   * Applet destroyed. Logout of Sametime.
   */
  public void destroy()
  {
    CommunityService comm = (CommunityService) 
             m_session.getCompApi(CommunityService.COMP_NAME);
    comm.logout();
            
    m_session.stop();
    m_session.unloadSession();            
  }
}
