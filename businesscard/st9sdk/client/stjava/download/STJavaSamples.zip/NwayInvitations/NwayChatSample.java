/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import com.lotus.sametime.core.comparch.*;
import com.lotus.sametime.core.constants.EncLevel;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.places.*;

/**
 * N-way chats are Places under the covers.  This sample demonstrates how to create a place or join an existing
 * place and respond to different Place / Section events.
 *
 * It will automatically respond to every user entered event by saying hi - this demonstrates how to handle Section
 * events within the n-way chat.
 *
 * It will automatically respond to every message - this demonstrates how to receive / send text messages
 * within the n-way chat.
 */
public class NwayChatSample implements PlacesServiceListener
{
	private STSession m_session = null;
	private PlacesService m_placesSvc = null;
	private Place m_place = null;
	private String m_placeName = "";
	private String m_placeDisplayName = "";
	private String m_password = "";
	private short m_creationMode = PlacesConstants.PLACE_CREATION_DONT_CARE;

	public NwayChatSample(STSession session, String placeName, String placeDisplayName, String password, short creationMode)
	{
		System.out.println("Creating NwayChatSample with: " + placeName + "," + placeDisplayName + "," + password + "," + creationMode);
		m_session = session;
		m_placeName = placeName;
		m_placeDisplayName = placeDisplayName;
		m_password = password;
		m_creationMode = creationMode;

		m_placesSvc = (PlacesService) m_session.getCompApi(PlacesService.COMP_NAME);
		m_placesSvc.addPlacesServiceListener(this);
		if (m_placesSvc.isServiceAvailable())
		{
			createAndEnterPlace();
		}
	}

	private void createAndEnterPlace()
	{
		if (m_place == null)
		{
	    	System.out.println("Creating Place, ID = " + m_placeName);
			m_place = m_placesSvc.createPlace(
					m_placeName,		 					// place unique name
					m_placeDisplayName, 					// place display name
	                EncLevel.ENC_LEVEL_RC2_40, 				// encryption level
	                0,                            			// place type
	                PlacesConstants.PLACE_PUBLISH_DONT_CARE);
			m_place.addPlaceListener(new PlaceEventsListener());
			m_place.enter(m_password, m_creationMode, true);
		}
	}

    public void serviceAvailable(PlacesServiceEvent event)
    {
    	createAndEnterPlace();
    }

    public void serviceUnavailable(PlacesServiceEvent event)
    {
    	System.out.println("PlacesService is not available.");
    }

	/**
	 * A listener for place events.
	 */
	class PlaceEventsListener extends PlaceAdapter
	{
		public void entered(PlaceEvent event)
		{
			System.out.println("Entered place: " + event.getPlace().getName());

			// Now we setup the auto-welcome part of this sample - it will say hi to anyone that joins
			m_place.getMySection().addSectionListener(new AutoWelcomeSectionListener());

			// Now we setup the auto-responder part of this sample - it will auto-respond to any message
			m_place.getMyselfInPlace().addMyMsgListener(new AutoResponderMsgListener());
		}

		public void enterFailed(PlaceEvent event)
		{
			System.out.println("Place enter failed with reason: 0x" + Integer.toHexString(event.getReason()));
		}
	}

	/**
	 * This class just extends the SectionListener adapter class so that we can just override the usersEntered method.
	 *
	 * Here we will automatically respond to every user entered event by saying hi - this demonstrates how to handle Section
	 * events within the n-way chat.
	 */
	class AutoWelcomeSectionListener extends SectionAdapter
	{
	    public void usersEntered(SectionEvent event)
	    {
	    	UserInPlace[] users = event.getUsers();
	    	for (int i = 0; i < users.length; i++)
	    	{
				// Don't welcome if I'm the one who entered
				if (users[i] != m_place.getMyselfInPlace())
				{
		    		String welcome = "Hi " + users[i].getDisplayName();
		    		m_place.getMySection().sendText(welcome);
				}
	    	}
	    }
	}

	/**
	 * This class just extends the MyMsgListener adapter class so that we can just override the textReceived method.
	 *
	 * Here we will automatically respond to every message - this demonstrates how to receive / send text messages
	 * within the n-way chat.
	 */
	class AutoResponderMsgListener extends MyMsgAdapter
	{
		public void textReceived(MyselfEvent event)
		{
			// Don't auto-respond if the message came from me
			if (event.getSender() != m_place.getMyselfInPlace())
			{
				String sender = ((STUser)event.getSender()).getDisplayName();
				String response = "<AUTORESPONSE> Got the following message from " + sender + ": " + event.getText();
				m_place.getMySection().sendText(response);
			}
		}
	}
}