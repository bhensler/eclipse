/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import java.util.*;
import java.net.URL;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.constants.STError;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.community.*;
import com.lotus.sametime.storage.*;
import com.lotus.sametime.awarenessui.list.AwarenessList;
import com.lotus.sametime.awarenessui.av.AVController;
import com.lotus.sametime.commui.*;

/**
 * The buddy list frame. Part of Buddy List Applet sample.
 */
public class BuddyListFrame extends Frame
    implements LoginListener, ResolveViewListener, 
               ActionListener, ItemListener, 
               StorageServiceListener
  
{
  private STSession m_session;
  private CommunityService m_commService;
  private StorageService m_storageService;
  private Integer m_nReqID;
  private AwarenessList m_awarenessList;
  private MenuItem m_menuAddToList;
  private MenuItem m_menuRemoveFromList;
  private MenuItem m_menuWhoCanSeeMe;
  private Choice m_statusChoices;

  private final static int BUDDY_LIST_ATT_KEY = 0xFFFF;

  private final String DISCONNECTED = "Disconnected";
  private final String ACTIVE = "I Am Active";
  private final String AWAY = "I Am Away";
  private final String DND = "Do Not Disturb Me";   

  /**
   * BuddyListFrame constructor
   */
  public BuddyListFrame(STSession session)
  {
    super("Sametime Buddy List");
    m_session = session;
    
    m_commService = (CommunityService)
      m_session.getCompApi(CommunityService.COMP_NAME);
    m_commService.addLoginListener(this);

    while (m_storageService == null) { 
		m_storageService = (StorageService)
		  m_session.getCompApi(StorageService.COMP_NAME);          
    }
    m_storageService.addStorageServiceListener(this);
    
    addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent e)
        {
          storeBuddyList();
          dispose();
        }
      });

    init();
  }
    
  /**
   * Setup the buddy list frame.
   */
  public void init()
  {
    setLayout(new BorderLayout());
        
    m_awarenessList = new AwarenessList(m_session, true);
    add(m_awarenessList, BorderLayout.CENTER);
        
    m_statusChoices = new Choice();
    m_statusChoices.setEnabled(false);
    m_statusChoices.addItem(DISCONNECTED);
    add(m_statusChoices, BorderLayout.SOUTH);
    m_statusChoices.addItemListener(this);

    AVController avController =
        new AVController(m_awarenessList.getModel());
    avController.enableDelete(true);
    m_awarenessList.setController(avController);
        
    m_menuAddToList = new MenuItem("Add to List...");
    m_menuAddToList.addActionListener(this);
    
    m_menuRemoveFromList = new MenuItem("Remove from List");
    m_menuRemoveFromList.addActionListener(this);

    m_menuWhoCanSeeMe = new MenuItem("Who Can See Me...");
    m_menuWhoCanSeeMe.addActionListener(this);
        
    Menu menuOptions = new Menu("People");
    menuOptions.add(m_menuAddToList);
    menuOptions.add(m_menuRemoveFromList);
    menuOptions.add(m_menuWhoCanSeeMe);

    MenuBar menuBar = new MenuBar();
    menuBar.add(menuOptions);

    setMenuBar(menuBar);
    
    pack();
    
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    setLocation((int)((d.width - getSize().width)/2), 
                (int)((d.height - getSize().height)/2));  
  }
 
  /**
   * Logged in event. Update the choice control with all the
   * status options.
   */
  public void loggedIn(LoginEvent event)
  {
    System.out.println("Logged In");
    m_awarenessList.addUser(
                   (STUser)event.getLogin().getMyUserInstance()); 
    
    m_statusChoices.setEnabled(true);
    m_statusChoices.removeAll();
    m_statusChoices.addItem(ACTIVE);
    m_statusChoices.addItem(AWAY);
    m_statusChoices.addItem(DND);
  }
  
  /**
   * Logged out event. Reset the choice control to show 
   * "Disconnected" and disabled.
   */
  public void loggedOut(LoginEvent event)
  {
    System.out.println("Logged Out");
	  
    m_statusChoices.setEnabled(false);
    m_statusChoices.removeAll();
    m_statusChoices.addItem(DISCONNECTED);
  }
  
  /**
   * Called when the user chooses a status from the choice control
   */
  public void itemStateChanged(ItemEvent event) 
  {
    if (event.getSource() == m_statusChoices)
    {
      STUserStatus status;
      
      if (event.getItem().equals(ACTIVE))
        status = new STUserStatus(STUserStatus.ST_USER_STATUS_ACTIVE, 
                                  0, ACTIVE);
      else if (event.getItem().equals(AWAY))
        status = new STUserStatus(STUserStatus.ST_USER_STATUS_AWAY, 
                                  0, AWAY);
      else if (event.getItem().equals(DND))
        status = new STUserStatus(STUserStatus.ST_USER_STATUS_DND, 
                                  0, DND);
      else return;
      
      if (m_commService.isLoggedIn())
        m_commService.getLogin().changeMyStatus(status);
    }
  }
    
  /**
   * Load the buddy list from the server using the Storage Service.
   */
  void loadBuddyList()
  {
    m_nReqID = m_storageService.queryAttr(BUDDY_LIST_ATT_KEY);
  }
  
  /**
   * Load the buddy list from an attribute returned by the Storage 
   * Service.
   */
  void loadBuddyListFromAttribute(STAttribute attr)
  {
    STUser user;
    String name; 
    String id;
    
    StringTokenizer tokenizer = 
      new StringTokenizer(attr.getString(),";");
    
    while(tokenizer.countTokens() >= 2)
    {
      name = tokenizer.nextToken();
      id = tokenizer.nextToken();
                
      user = new STUser(new STId(id, ""), name, "");
      m_awarenessList.addUser(user);
    }
  }

  /**
   * Store the buddy list to the server using the Storage Service.
   */
  void storeBuddyList()
  {
    STUser[] usersList = m_awarenessList.getItems();
        
    StringBuffer buffer = new StringBuffer();
    for(int i=0; i<usersList.length; i++)
    {
      buffer.append(usersList[i].getName());
      buffer.append(";");
      buffer.append(usersList[i].getId().getId());
      buffer.append(";");
    }
    
    STAttribute attribute = new STAttribute(BUDDY_LIST_ATT_KEY, 
                                            buffer.toString());
    
    m_nReqID = m_storageService.storeAttr(attribute);
  }

  /**
   * Action event listener. Called when one of the menus is selected.
   */
  public void actionPerformed(ActionEvent event)
  {
    Object src = event.getSource();

    if (src == m_menuAddToList)
      addToList();
    else if(src == m_menuRemoveFromList)
      removeFromList();
    else if (src == m_menuWhoCanSeeMe)
      whoCanSeeMe();
  }

  /**
   * Show the add dialog.
   */
  void addToList()
  {
    AddDialog addDialog = new AddDialog(this, m_session, "Add User");
    addDialog.addResolveViewListener(this);
    addDialog.setVisible(true);
  }
  
  void removeFromList()
  {
      m_awarenessList.removeUsers(m_awarenessList.getSelectedItems());
  }

  /**
   * Show the privacy (who-can-see-me) dialog.
   */
  void whoCanSeeMe()
  {
    PrivacyDialog dialog = new PrivacyDialog(this, m_session);
    dialog.setVisible(true);
  }
    
  /**
   * A user resolve request from the add dialog was successful.
   */
  public void resolved(ResolveViewEvent event)
  {
    STUser user = event.getUser();
    m_awarenessList.addUser(user);
  }
    
  /**
   * A resolve request from the add dialog failed. 
   */
  public void resolveFailed(ResolveViewEvent event)
  {
    System.out.println("Couldn't find user. Reason = " +
                                        event.getReason());
  }

  /**
   * Called as a response to a query attribute request.
   */
  public void attrQueried(StorageEvent event)
  {
    if (m_nReqID == event.getRequestId())
    {
      if(event.getRequestResult() == STError.ST_OK)
      {
        loadBuddyListFromAttribute((STAttribute)
                event.getAttrList().firstElement());
      }
      else
      {
        System.out.println("Couldn't load buddy list");
      }
    }     
  }

  /**
   * Called as a response to a store attribute request.
   */
  public void attrStored(StorageEvent event)
  {
    if (m_nReqID == event.getRequestId() && 
        event.getRequestResult() != STError.ST_OK)
    {
      System.out.println("Couldn't store buddy list");
    }
  }
  
  /**
   * Indicates the the Storage Service is now available
   */
  public void serviceAvailable(StorageEvent event)
  {
    loadBuddyList();  
  }

  /**
   * Indicates that the Storage Service is unavailable.
   */
  public void serviceUnavailable(StorageEvent event)
  {
  }

  /**
   * Indicates that one or more storage attributes of this login 
   * were modified by a different login.
   */
  public void attrUpdated(StorageEvent event)
  {
  }
}
