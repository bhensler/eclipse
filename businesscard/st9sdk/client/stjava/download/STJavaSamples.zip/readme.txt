Sametime 8.5.1 Java Toolkit Samples Readme
----------------------------------------

Follow these steps to run the Sametime Java Toolkit samples:

1. Extract this STJavaSamples.zip file in a folder under the 
   HTML directory of the Sametime server. The HTML folder 
   is usually under the path: C:\Sametime\Data\domino\html.

2. Copy the contents of the Java Toolkit bin folder to the same folder
   where you extracted the samples.

3. If the sample is an applet, modify the sample HTML file by replacing 
   the user name and password in the file with your own. All samples are 
   preconfigured to log in as the user 'Tom' with the password 'sametime.' 
   If you register this user on the Sametime server, you will not need to 
   modify the sample HTML files.

4. Run the sample. If the sample is an applet, run it using Microsoft
   Internet Explorer, Mozilla Firefox, or the standard applet viewer
   utility provided by Sun Microsystems. If the sample is a Java
   application, run it using the Java development environment.

NOTE: Many of these samples utilize APIs in the Java Toolkit that have
been deprecated starting with Sametime 7.5. These samples still demonstrate
valuable examples of how to use the core Java Toolkit components.  The deprecated
components are AWT-based APIs that listen to and provide UI wrappers to the core
components.  All references to the deprecated components will be removed in the
next release. Please see the tutorial and developers guide for more information on
all Java Toolkit APIs.

NOTE: A new set of samples for N-Way invitations has been added in 8.5.1.  These are
command-line samples, not applets.  Follow the directions within the NwayInvitations
directory to run these samples.