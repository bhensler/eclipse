N-Way Chat Invitation Samples

The samples in this directory demonstrate how to use the Invitation APIs
to invite other users to n-way (multi-person) chats and how to accept
invites to n-way chats.

The samples are essentially BOTs that do the following:

    NwayAutoJoin

        The NwayAutoJoin sample automatically accepts an invitation to an n-way chat.
        Once accepted, it will create an NwayChatSample (see below) based on the
        invitation.

    NwayInviter

        NwayInviter sample will login, resolve the specified user and invite them to
        an n-way chat. Once accepted, it will create an NwayChatSample (see below)
        based on the invitation.

    NwayChatSample

        N-way chats are Places under the covers. This sample demonstrates how to create
        a place or join an existing place and respond to different Place / Section events.

        It will automatically respond to every user entered event by saying hi - this
        demonstrates how to handle Section events within the n-way chat.

        It will automatically respond to every message - this demonstrates how to receive /
        send text messages within the n-way chat.

To run the samples, invoke the main classes with the Java Toolkit on the classpath and specify the required parameters:

    java NwayAutoJoin <servername> <username> <password>
    
    java NwayInviter <servername> <username> <password> <usernameToInvite>