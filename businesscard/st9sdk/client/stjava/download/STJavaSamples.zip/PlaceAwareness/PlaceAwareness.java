/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.applet.*;
import java.awt.*;
import java.awt.event.*;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.awarenessui.placelist.PlaceAwarenessList;
import com.lotus.sametime.awarenessui.av.AVController;
import com.lotus.sametime.community.*;
import com.lotus.sametime.places.*;
import com.lotus.sametime.core.constants.EncLevel;

/**
 * Place Awareness Sample using the Place Awareness List.
 */
public class PlaceAwareness extends Applet implements LoginListener,
                                                      ActionListener
{
  /**
   * Our session.
   */
  private STSession m_session;
      
  /**
   * The place awareness list.
   */
  private PlaceAwarenessList m_placeAwarenessList;
      
  /**
   * Enter/leave place button
   */
  private Button m_button;
      
      
  /**
   * The place being watched. 
   */
  private Place m_place;
      
     
  /**
   * The entry point for the applet. 
   */
  public void init()
  {
    try
    {
      // generate a new session with a unique name
      m_session = new STSession("Place Awareness List " + this);
                      
      // Call the session to load all available components 
      m_session.loadAllComponents();
      m_session.start();
                      
      setLayout(new BorderLayout());

      //add a label with the user name at top of the list
      Label label = new Label("User: " + getParameter("loginName"));
      label.setAlignment(Label.CENTER);
      add(label, BorderLayout.NORTH);
                      
      // create the new list view
      m_placeAwarenessList = new PlaceAwarenessList(m_session, true);
      add(m_placeAwarenessList, BorderLayout.CENTER);
                      
      //add the enter/leave button at the bottom 
      m_button = new Button("Press To Enter Place");
      add(m_button, BorderLayout.SOUTH);
      m_button.setEnabled(false);
      m_button.addActionListener(this);

      // The default right-click menu for the awareness list does not
      // give audio & video as options. We can change that by 
      // changing the controller to a different one.
      AVController avController =
          new AVController(m_placeAwarenessList.getModel());
      m_placeAwarenessList.setController(avController);
                      
      // login to the community
      login();
    }
    catch(DuplicateObjectException e)
    {
      // This exception is thrown if an STSession with the same 
      // name has already been created.
      e.printStackTrace();
    }                     
  }  
    
  /**
   * Login to the community using the user name and password 
   * parameters from the html.
   */
  private void login()
  {
    // get a reference to the community service. We use the session 
    // object which contains a reference to all the components that 
    // were loaded to get a reference to the community service. 
    CommunityService comm = (CommunityService) 
              m_session.getCompApi(CommunityService.COMP_NAME);
              
    // register a listener to the login/logout events.
    comm.addLoginListener(this);
              
    // login to the community
    comm.loginByPassword(getCodeBase().getHost(),
                          getParameter("loginName"),
                          getParameter("password"));
              
    // Wait for the loggedin() event to enter the place
  }
      
  /**
   * Login event. 
   */
  public void loggedIn(LoginEvent event)
  {
    //Get refernce to the place service
    PlacesService placesService = (PlacesService) 
               m_session.getCompApi(PlacesService.COMP_NAME);
              
    //Create a new place object
    m_place = placesService.createPlace("Tom's Place", 
                                        "My Place", 
                                        EncLevel.ENC_LEVEL_RC2_40,
                                        0);
                            
    //bind the list to the specified place.
    m_placeAwarenessList.bindPlace(m_place);
              
    //enable enter/leave button
    m_button.setEnabled(true);
  }
      
  /**
   * Logout event
   */
  public void loggedOut(LoginEvent event)
  {
    //disable enter/leave button
    m_button.setEnabled(false);    
  }
      
  /**
   * Action event. Leave/Enter button clicked enter or leave
   * place accordingly.
   */
  public void actionPerformed(ActionEvent evt)
  {
    if(evt.getActionCommand().equals("Leave"))
    {
      //enter the place
      m_place.leave(0);
      m_button.setActionCommand("Enter");
      m_button.setLabel("Press To Enter Place");
    }
    else
    {
      //enter the place
      m_place.enter();
      m_button.setActionCommand("Leave");
      m_button.setLabel("Press To Leave Place");
    }
  }      
      
  /**
   * Applet destroyed. Logout of Sametime.
   */
  public void destroy()
  {
    CommunityService comm = (CommunityService) 
          m_session.getCompApi(CommunityService.COMP_NAME);
    comm.logout();
            
    m_session.stop();
    m_session.unloadSession();        
  }
}
