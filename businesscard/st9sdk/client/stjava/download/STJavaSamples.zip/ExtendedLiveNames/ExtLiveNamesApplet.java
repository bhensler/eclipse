/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;
import java.net.URL;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.types.STUser;
import com.lotus.sametime.core.types.STUserStatus;
import com.lotus.sametime.community.*;
import com.lotus.sametime.lookup.*;
import com.lotus.sametime.awarenessui.list.AwarenessList;
import com.lotus.sametime.awarenessui.av.AVController;
import com.lotus.sametime.chatui.ChatUI;
import com.lotus.sametime.chatui.MeetingListener;
import com.lotus.sametime.chatui.MeetingInfo;

/**
 * Sample applet that displays a list of live user names, allows 
 * the user to change his online status and allows initiating
 * and receiving invitations to meetings.
 */
public class ExtLiveNamesApplet extends Applet
    implements LoginListener, ResolveListener, 
               ItemListener, MeetingListener
{
  private STSession m_session;
  private CommunityService m_comm;    
  private AwarenessList m_awarenessList;
  private Choice m_statusChoices;
  
  private final String DISCONNECTED = "Disconnected";
  private final String ACTIVE = "I Am Active";
  private final String AWAY = "I Am Away";
  private final String DND = "Do Not Disturb Me";
    
  /**
   * Applet initialized. Create the session, load all components,
   * start the session and then login.
   */
  public void init()
  {
    try
    {
      m_session = new STSession("LiveNamesApplet " + this);
      m_session.loadAllComponents();
      m_session.start();
            
      setLayout(new BorderLayout());
      m_awarenessList = new AwarenessList(m_session, true);
      add(m_awarenessList, BorderLayout.CENTER);
      
      m_statusChoices = new Choice();
      m_statusChoices.setEnabled(false);
      m_statusChoices.addItem(DISCONNECTED);
      add(m_statusChoices, BorderLayout.SOUTH);
      m_statusChoices.addItemListener(this);
            
      ChatUI chatui = (ChatUI)m_session.getCompApi(ChatUI.COMP_NAME);
      chatui.addMeetingListener(this);
      
      AVController avController =
          new AVController(m_awarenessList.getModel());
      m_awarenessList.setController(avController);

      login();
    }
    catch(DuplicateObjectException e)
    {
      e.printStackTrace();
    }
  }
    
  /**
   * Login to the community using the user name and password 
   * parameters from the html.
   */
  private void login()
  {
    m_comm = (CommunityService)
        m_session.getCompApi(CommunityService.COMP_NAME);
    m_comm.addLoginListener(this);     
    m_comm.loginByPassword(getCodeBase().getHost(),
                         getParameter("loginName"),
                         getParameter("password"));     
  }
    
  /**
   * Logged in event. Print logged in msg to console.
   * Resolve the users to add to the awareness list. 
   */
  public void loggedIn(LoginEvent event)
  {
    System.out.println("Logged In");
    m_awarenessList.addUser(
                    (STUser)event.getLogin().getMyUserInstance());
    m_statusChoices.setEnabled(true);
    m_statusChoices.removeAll();
    m_statusChoices.addItem(ACTIVE);
    m_statusChoices.addItem(AWAY);
    m_statusChoices.addItem(DND);
    
    LookupService lookup = (LookupService)
      m_session.getCompApi(LookupService.COMP_NAME);

    Resolver resolver =
        lookup.createResolver(false,  // Return all matches.
                            false,  // Non-exhaustive lookup.
                            true,   // Return resolved users.
                            false); // Do not return resolved groups.
        
    resolver.addResolveListener(this);    
    String[] userNames = getUserNames();
    resolver.resolve(userNames);
  }

  /**
   * Helper method to read a list of user names from the html 
   * parameter 'watchedNames'.
   */
  String[] getUserNames()
  {
    String users = getParameter("watchedNames");
      
    StringTokenizer tokenizer = new StringTokenizer(users, ",");
    String[] userNames = new String[tokenizer.countTokens()];
                 
    int i = 0;
    while(tokenizer.hasMoreTokens())
    {
      userNames[i++] = tokenizer.nextToken();
    }
    return userNames;
  }

  /**
   * Users resolved succesfuly event. An event will be generated for 
   * each resolved user. Add the resolved user to the awareness list.
   */
  public void resolved(ResolveEvent event)
  {
    m_awarenessList.addUser((STUser) event.getResolved());
  }    
 
  /**
   * Handle a resolve conflict event. Will be received in the case 
   * that more then one match was found for a specified user name. 
   * Add the users to the awareness list anyway.
   */
  public void resolveConflict(ResolveEvent event)
  {
    STUser[] users = (STUser[]) event.getResolvedList();    
    m_awarenessList.addUsers(users);
  }
  
  /**
   * Resolve failed. No users are available to add to the list.
   */
  public void resolveFailed(ResolveEvent event)
  {
  }
  
  /**
   * Called when the user chooses a status from the choice control
   */
  public void itemStateChanged(ItemEvent event) 
  {
    if (event.getSource() == m_statusChoices)
    {
      STUserStatus status;
      
      if (event.getItem().equals(ACTIVE))
        status = new STUserStatus(STUserStatus.ST_USER_STATUS_ACTIVE, 
                                  0, ACTIVE);
      else if (event.getItem().equals(AWAY))
        status = new STUserStatus(STUserStatus.ST_USER_STATUS_AWAY, 
                                  0, AWAY);
      else if (event.getItem().equals(DND))
        status = new STUserStatus(STUserStatus.ST_USER_STATUS_DND, 
                                  0, DND);
      else return;
      
      if (m_comm.isLoggedIn())
        m_comm.getLogin().changeMyStatus(status);
    }
  }
  
  /**
   * Launch meeting event. Open a browser at the specified URL.
   */
  public void launchMeeting(MeetingInfo meetingInfo, URL url)
  {
    AppletContext context = getAppletContext();
    context.showDocument(url, "_blank");
  }
	
  /**
   * Meeting creation failed event.
   */
  public void meetingCreationFailed(MeetingInfo meetingInfo, 
                                    int reason)
  {
    System.err.println("Create meeting failed reason = " + reason);
  }
  
  /**
   * Logged out event. Print logged out msg to console. Leave default
   * behavior which will display a dialog box. 
   */
  public void loggedOut(LoginEvent event)
  {
    System.out.println("Logged Out");
    
    m_statusChoices.setEnabled(false);
    m_statusChoices.removeAll();
    m_statusChoices.addItem(DISCONNECTED);
  }

  /**
   * Applet destroyed. Logout, stop and unload the session.
   */
  public void destroy()
  {
    m_comm.logout();
    m_session.stop();
    m_session.unloadSession();
  }
}
