/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;

import com.lotus.sametime.places.*;
import com.lotus.sametime.community.*;
import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.constants.EncLevel;


/**
 * This applet allows chat over different sections of a place. It accepts 3 
 * parameters from the HTML file: SERVER_NAME, LOGIN_NAME and password which it 
 * then uses to login. 
 */
public class PlacesApplet extends Applet implements LoginListener, 
    ActionListener, ItemListener, SectionListener, MyMsgListener, MySectionListener
{
    /**
     * The place name.
     */
    private static final String PLACE_NAME = "SamplePlace";
    
    /**
     * The session object.
     */
    private STSession m_session;

    /**
     * The community service. (For login).
     */
    private CommunityService m_commService;
    
    /**
     * The places service.
     */
    private PlacesService m_placesService;
    
    /**
     * The place were going to deal with.
     */
    private Place m_place;
    
    /**
     * The current section wer'e in.
     */
    private Section m_mySection;
    
    /**
     * The list of sections in the place.
     */
    private Hashtable m_sections = new Hashtable();
    
    /**
     * The list of users in the current section we're in.
     */
    private Hashtable m_users = new Hashtable();
    
    // UI components.
    private Button    m_btnSend;
    private TextField m_tfSend;
    private TextArea  m_taTranscript;
    private Choice    m_chSections;
    private Choice    m_chScope;
    private List      m_peopleList;
    
    //
    // Applet life cycle.
    //
    /**
     * Initialize the sametime components.
     */
    public void init()
    {
        try
        {
            m_session = new STSession("Places Session" + this);
            m_session.loadSemanticComponents();
            m_session.start();
        }
        catch(DuplicateObjectException e)
        {
            e.printStackTrace();
        }
        
        // Get a reference to the components we are interested in.
        m_commService = (CommunityService)
                         m_session.getCompApi(CommunityService.COMP_NAME);
        m_commService.addLoginListener(this);
        
        m_placesService = (PlacesService)
                           m_session.getCompApi(PlacesService.COMP_NAME);
        
        initUI();
    }
    
    /**
     * Login to the community server.
     */
    public void start()
    {
        String serverName = getCodeBase().getHost().toString();
        String loginName  = getParameter("loginName");
        String password   = getParameter("password");
        
        m_commService.loginByPassword(serverName, 
                                      loginName, password); 
        
        
    }
    
    /**
     * Logout.
     */
   
    
    public void destroy()
    {
      m_commService.logout();
      m_session.stop();
      m_session.unloadSession();
    }
    
    /**
     * A notification that wer'e logged in.
     */
    public void loggedIn(LoginEvent event)
    {
        System.out.println("Sample: Logged in");
        
        // Create the place wer'e going to work with, and enter.
        m_place = m_placesService.createPlace(PLACE_NAME, PLACE_NAME,  
                                              EncLevel.ENC_LEVEL_DONT_CARE, 0);
        // Add an adapter to be the listener to this place.
        addPlaceListener();
        m_place.enter();
    }
    
    /**
     * Logged out of the server. 
     */
    public void loggedOut(LoginEvent event)
    {
        System.out.println("Sample: Logged out");
    }
    
    /**
     * Add a PlaceAdapter to listen to the events we care about.
     */
    private void addPlaceListener()
    {
        m_place.addPlaceListener(new PlaceAdapter()
        {
            public void entered(PlaceEvent event)
            {
                PlacesApplet.this.entered(event);
            }
            
            public void enterFailed(PlaceEvent event)
            {
                PlacesApplet.this.enterFailed(event);
            }
            
            public void left(PlaceEvent event)
            {
                PlacesApplet.this.left(event);
            }
            
            public void sectionAdded(PlaceEvent event)
            {
                PlacesApplet.this.sectionAdded(event);
            }
            
            public void sendFailed(PlaceMemberEvent event)
            {
                PlacesApplet.this.sendFailed(event);
            }
            
        });
    }
    
    //
    // Place listener interface.
    //
    
    /**
     * Entered the place.
     */
    private void entered(PlaceEvent event)
    {
        // Listen to my section in order to get notification on its users.
        m_mySection = m_place.getMySection();
        m_mySection.addSectionListener(this);
        
        MyselfInPlace myself = m_place.getMyselfInPlace();
        
        // Listen for incoming messages.
        myself.addMyMsgListener(this);
        
        // Listen for section changes.
        myself.addMySectionListener(this);
        
        enableGuiItems(true);    
    }

    /**
     * Failed to enter the place. Better luck next time.
     */
    private void enterFailed(PlaceEvent event)
    {
        System.out.println("Sample: Failed to enter to the place. Reason: " +
                           event.getReason());
    }

    /**
     * Left the place for some reason.
     */
    private void left(PlaceEvent event)
    {
        System.out.println("Sample: Left the place. Reason: " +
                           event.getReason());
        
        enableGuiItems(false);
    }

    /**
     * New section in the place.
     */
    public void sectionAdded(PlaceEvent event)
    {
        Section newSection = event.getSection();
        Integer sectionId = newSection.getMemberId();
        String sectionKey = "Section" + sectionId.toString();
        
        m_sections.put(sectionKey, newSection);
        m_chSections.add(sectionKey);
    }
    
    //
    // Section listener.
    //
    /**
     * New users have entered the section.
     */
    public void usersEntered(SectionEvent event)
    {
        String userName;
        UserInPlace[] newUsers = event.getUsers();
        for (int i = 0; i < newUsers.length; i++)
        {
            userName = newUsers[i].getDisplayName();
            m_users.put(userName, newUsers[i]);
            m_peopleList.add(userName);
        }
        
        m_peopleList.select(0);
    }

    /**
     * A user has left the section.
     */
    public void userLeft(SectionEvent event)
    {
        String userName = event.getUser().getDisplayName();
        m_users.remove(userName);
        m_peopleList.remove(userName);
        
        if(m_peopleList.getSelectedIndex() == -1)
        {
            m_peopleList.select(0);
        }
    }
    
    /**
     * A attempt to send a message was failed.
     */
    public void sendFailed(PlaceMemberEvent event)
    {
        m_taTranscript.append("\n ************Failed to send the message. Reason: " + 
                              Integer.toHexString(event.getReason()) + 
                              "h ************ \n\n");
    }
    
    /**
     * AWT events.
     */
    public void actionPerformed(ActionEvent event)
    {
        if (event.getSource() == m_btnSend)
        {
            PlaceMember receiver;
            String text = m_tfSend.getText();
            String scope = m_chScope.getSelectedItem();
            
            // Get the receiver place member according to the selected scope.
            if (scope.equals("Scope: PLACE"))
            {
                receiver = m_place;
            }
            else if (scope.equals("Scope: SECTION"))
            {
                receiver = m_mySection;
            }
            else 
            {
                String selectedUser = m_peopleList.getSelectedItem();
                receiver = (UserInPlace)m_users.get(selectedUser);
            }
            
            receiver.sendText(text);
            m_tfSend.setText("");
        }
    }

    /**
     * 
     */
    public void itemStateChanged(ItemEvent event)
    {
        if (event.getSource() == m_chSections)
        {
            String sectionKey = (String)event.getItem();
           
            Section newSection = (Section)m_sections.get(sectionKey);
            MyselfInPlace myself = m_place.getMyselfInPlace();
            
            // Move to the selected section. See sectionChanged() below.
            myself.changeSection(newSection);
       }
    }
    
    //
    // My section listener.
    //
    
    /**
     * Navigated to a new section.
     */
    public void sectionChanged(MyselfEvent event)
    {
        System.out.println("Sample: Section changed");
        
        m_users.clear();
        m_peopleList.removeAll();
        
        m_mySection.removeSectionListener(this);
        m_mySection = event.getSection();
        m_mySection.addSectionListener(this);
    }

    /**
     * Unable to switch sections.
     */
    public void changeSectionFailed(MyselfEvent event)
    {
        System.out.println("Sample: Failed to change a section. Reason: " +
                           event.getReason());
    }
    
    //
    // My Msg Listener.
    //

    /**
     * A text message was received.
     */
    public void textReceived(MyselfEvent event)
    {
        PlaceMember sender = event.getSender();
        if (sender instanceof UserInPlace)
        {
            String senderName = ((UserInPlace)sender).getDisplayName();
            String scope;
            if (event.getScope() == PlacesConstants.SCOPE_PLACE)
            {
                scope = "Place    ";
            }
            else if (event.getScope() == PlacesConstants.SCOPE_SECTION)
            {
                scope = "Section ";
            }
            else 
            {
                scope = "User     ";
            }
            
            m_taTranscript.append(scope + senderName + "          ");
            m_taTranscript.append(event.getText() + "\n");
            
            m_tfSend.requestFocus(); 
        }
    }

    public void dataReceived(MyselfEvent event)
    {}

    //
    // Helpers.
    //
    
    /**
     * Set up the ui components.
     */
    private void initUI()
    {
        setLayout(new BorderLayout());
        
        Panel sendPanel = new Panel(new BorderLayout());
        sendPanel.add("East", m_btnSend = new Button("Send"));
        sendPanel.add("Center", m_tfSend = new TextField());
        sendPanel.add("West", m_chScope = new Choice());
        m_chScope.add("Scope: PLACE");
        m_chScope.add("Scope: SECTION");
        m_chScope.add("Scope: USER");
        
        Panel chatPanel = new Panel(new BorderLayout());
        chatPanel.add("South", sendPanel);
        chatPanel.add("Center", m_taTranscript = new TextArea());
        m_taTranscript.setFont(new Font("Courier New", Font.PLAIN, 12));
        m_taTranscript.setForeground(Color.blue);
        m_taTranscript.setEnabled(false);
        
        Label header = new Label();
        header.setFont(new Font("Dialog", Font.BOLD, 12));
        header.setText("SCOPE        SENDER                TEXT");
        chatPanel.add("North", header);
        
        Panel listPanel = new Panel(new BorderLayout());
        listPanel.add("North", m_chSections = new Choice());
        listPanel.add("Center", m_peopleList = new List());
        m_peopleList.setForeground(Color.magenta);
        
        m_btnSend.addActionListener(this);
        m_chSections.addItemListener(this);
        
        // Enable the gui items only after we enter to the place.
        enableGuiItems(false);
    
        add("East", listPanel);
        add("Center", chatPanel);
    }
    
    private void enableGuiItems(boolean enable)
    {
        m_btnSend.setEnabled(enable);
        m_tfSend.setEnabled(enable);
        m_peopleList.setEnabled(enable);
        m_chScope.setEnabled(enable);
        m_chSections.setEnabled(enable);
        
        m_tfSend.requestFocus();
    }

    public void addAllowedUsersFailed(SectionEvent event)
    {}

    public void removeAllowedUsersFailed(SectionEvent event)
    {}

    public void removeAttributeFailed(PlaceMemberEvent event)
    {}

    public void attributeChanged(PlaceMemberEvent event)
    {}

    public void attributeRemoved(PlaceMemberEvent event)
    {}

    public void queryAttrContentFailed(PlaceMemberEvent event)
    {}

    public void changeAttributeFailed(PlaceMemberEvent event)
    {}
}
    
