/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.util.*;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.constants.*;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.community.*;
import com.lotus.sametime.im.*;
import com.lotus.sametime.commui.*;
import com.lotus.sametime.guiutils.chat.ChatArea;
import com.lotus.sametime.guiutils.misc.*;
import com.lotus.sametime.resourceloader.*;

public class ImApplet extends Applet 
  implements LoginListener, ImServiceListener, ImListener,
              CommUIListener, ActionListener							
{
  private STSession m_session;
  private CommunityService m_comm;
  private InstantMessagingService  m_imService;
  private CommUI m_commUiService;
  private Vector m_ImOpened = new Vector();
  	
  private String m_myName ="";
  private TextField m_imDestination =new TextField();
  private TextField m_imText= new TextField();
  private Button m_sendBtn = new Button("Send");
  private Font m_font = new Font("Dialog", Font.PLAIN, 12);
  private ChatArea m_transcript = new ChatArea(150,m_font,15);
  	
  public void init()
  {
    try
    {
      m_session = new STSession("ImApplet" + this);
            
      //we are not to loading the chatUi comp
      //because we are going to handle the events 
      //in different way
      m_session.loadSemanticComponents();
      new CommUIComp(m_session);
      new ResourceLoaderComp(m_session);
    }
    catch(DuplicateObjectException e)
    {
      e.printStackTrace();
    }
            
    m_session.start();
    initLayout();
    login();
  }
          
  /**
   * set the applet layout 
   */
  private void initLayout()
  {
    setLayout(new BorderLayout(0,0));
    Font labelFont = new Font("Dialog",14,Font.PLAIN);
    Panel northPnl = new Panel(new BorderLayout(10,0));
            
    Panel details = new Panel(new BorderLayout(0,0));
    details.add(new Label("Type your partner name here:"),
                BorderLayout.NORTH);
    details.add(m_imDestination,BorderLayout.SOUTH);
            
    Panel messagePnl = new Panel(new BorderLayout(0,0));
    messagePnl.add(new Label("Type your message here:"),
                   BorderLayout.NORTH);
    messagePnl.add(m_imText,BorderLayout.CENTER);
    messagePnl.add(m_sendBtn,BorderLayout.EAST);
    m_sendBtn.addActionListener(this);
            
    northPnl.add(details,BorderLayout.NORTH);
    northPnl.add(messagePnl,BorderLayout.SOUTH);
         
    add(northPnl,BorderLayout.NORTH );
    add(m_transcript,BorderLayout.CENTER);
    validate();
  }
  
  /**
   * Login to the community using the user name and password 
   * parameters from the html.
   */
  private void login()
  {
    m_comm = (CommunityService)
        m_session.getCompApi(CommunityService.COMP_NAME);
    		
    m_comm.addLoginListener(this);     

    m_comm.loginByPassword(getCodeBase().getHost().toString(),
                            getParameter("loginName"),
                            getParameter("password"));     		
  }
      
  /**
   * get an im object and send the text
   */
  public void sendText(Im im)
  {
    im.sendText(false,m_imText.getText());
	m_transcript.write(m_myName + ":", m_imText.getText(), Color.black);
    m_imText.setText(""); 
  }
      
  /**
   * Loggedin event receive only if loggedin successfully
   */
  public void loggedIn(LoginEvent event)
  {
    m_myName = m_comm.getLogin().getMyUserInstance().
                                         getDisplayName();
    m_transcript.writeSeparator("Loggedin :" + m_myName, 
                                Color.green);
    m_imService = (InstantMessagingService)
        m_session.getCompApi(InstantMessagingService.COMP_NAME);
    m_imService.registerImType(ImTypes.IM_TYPE_CHAT);			

    m_imService.addImServiceListener(this);
    		
    m_commUiService = (CommUI )
    m_session.getCompApi(CommUI.COMP_NAME);
    m_commUiService.addCommUIListener(this);
  }

  /**
   * Loggedin event receive only if loggedout 
   */
  public void loggedOut(LoginEvent event)
  {
    m_transcript.writeSeparator("Loggedout :" + m_myName,
                                Color.green);
  }

  /**
   * imReceived event received if someone try to open im to you,
   * check if you have already im with this person, if not add 
   * Im listener
   */
  public void imReceived(ImEvent event)
  {
    Im im = event.getIm();
    boolean imExsit = false;
    Im currentIm = null;
    
    for(int i = 0; i < m_ImOpened.size(); i++)
    {
      currentIm = (Im)m_ImOpened.elementAt(i);
      if(currentIm.equals(im))
      {
      imExsit = true;
      im = currentIm;
      break;
      }
    }
    
    if(!imExsit)
    {
      m_ImOpened.addElement(im);
      im.addImListener(this);
    }	
  }

  /**
   * if the send button was pressed take the name form the textField
   * and resolve for appropriate user
   */
  public void actionPerformed(ActionEvent event)
  {
    m_commUiService.resolve(m_imDestination.getText());
  }
         
  /**
   * resolved event receive aftere you send request to resolve a name
   * check if you already have im with this person,
   * if you have sent the text else open new im. 
   */
  public void resolved(CommUIEvent event)
  {
    STUser partner = event.getUser();
    Im im = m_imService.createIm(partner,
                        EncLevel.ENC_LEVEL_NONE,
                        ImTypes.IM_TYPE_CHAT);
      
    Im  currentIm = null;
    boolean imExsit = false;
    for(int i = 0; i < m_ImOpened.size(); i++)
    {
      currentIm = (Im)m_ImOpened.elementAt(i);
      if(currentIm.getPartner().equals(partner))
      {
        imExsit = true;
        im = currentIm;
        sendText(im);
        break;
      }
    }
    
    if(!imExsit)
    {
      m_ImOpened.addElement(im);
      im.addImListener(this);
      im.open();
    }
  }

  /**
   * resolveFailed event receive aftere you send request to resolve a 
   * name but no approrriate user was found.
   */
  public void resolveFailed(CommUIEvent event)
  {
    m_transcript.writeSeparator("resolve failed type another name",
                                Color.red);
    m_imDestination.setText("");
  }
      
  /**
   * if the user start the im (by im.open()) imOpened event will
   * be receved if the im open successfully
   */
  public void imOpened(ImEvent event)
  {
    event.getIm().sendText(false,m_imText.getText());
    m_transcript.write(m_myName + ":", m_imText.getText(), Color.black);
    m_imText.setText(""); 
  }

   /**
   * if the user start the im (by im.open()) imOpened event will
   * be receved openImFailed if the user you try to open im to is
   * offline or DND etc.
   */
  public void openImFailed(ImEvent evt)
  {
    System.out.println("openImFailed reason :"+evt.getReason());
    m_transcript.writeSeparator
      ("Failed to open im ,type another user name", Color.red);
      
    Im im = evt.getIm();
    im.removeImListener(this);
    m_ImOpened.removeElement(im);
  }

  /**
   * if, from any reason the im was closed.
   * you will need to remove the im from the open im list
   */
  public void imClosed(ImEvent event)
  {
    Im im = event.getIm();
    boolean imExsit = false;
    Im currentIm = null;
    
    for(int i = 0; i < m_ImOpened.size(); i++)
    {
      currentIm = (Im)m_ImOpened.elementAt(i);
      if(currentIm.equals(im))
      {
        imExsit = true;
        m_ImOpened.removeElement(im);
        im.close(0);
        im.removeImListener(this);
        break;
      }
    }
  }

   /**
   * textReceived print it to the screen
   */
  public void textReceived(ImEvent event)
  {
    String partnerName = event.getIm().getPartner().getDisplayName();
    m_transcript.write(partnerName + ":", event.getText(), Color.blue);
  }

  /**
   * DataReceived print a message to the screen
   */
  public void dataReceived(ImEvent evt)
  {
    System.out.println("Data Received data type = " + 
                       evt.getDataType());
  }
      
  public void destroy()
  {
    m_comm.logout();
    m_session.stop();
    m_session.unloadSession();
  }
}
