/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.community.*;
import com.lotus.sametime.directoryui.*;

/**
 * Directory Sample using the directory panel.
 */
public class Directory extends Applet 
  implements LoginListener, DirectoryListViewListener
{
  /**
   * Our session.
   */
   private STSession m_session;        
       	
  /**
   * Text area for displaying messages.
   */
  private TextArea m_textArea;
        
  /**
   * The entry point for the applet. 
   */
  public void init()
  {
    try
    {
      // generate a new session with a unique name
      m_session = new STSession("Directory Applet " + this);
                        
      // Call the session to load all available components 
      m_session.loadAllComponents();
      m_session.start();
                        
      setLayout(new BorderLayout());
      DirectoryPanel dirPanel = new DirectoryPanel(m_session);
      add(dirPanel, BorderLayout.CENTER);
                        
      //register a listener to receive selection change and 
      //double click events. 
      dirPanel.addDirectoryListViewListener(this);
                        
      m_textArea = new TextArea();
      add(m_textArea, BorderLayout.SOUTH);
                        
      // login to the community
      login();
    }
    catch(DuplicateObjectException e)
    {
      // This exception is thrown if an STSession with the same 
      // name has already been created.
      e.printStackTrace();
    }
  }
            
  /**
   * Login to the community using the user name and password 
   * parameters from the html.
   */
  private void login()
  {
    // get a reference to the community service. We use the session 
    // object which contains a reference to all the components that 
    // were loaded to get a reference to the community service. 
    CommunityService comm = (CommunityService) 
                    m_session.getCompApi(CommunityService.COMP_NAME);
                  
    // register a listener to the login/logout events.
    comm.addLoginListener(this);
                  
    // login to the community
    comm.loginByPassword(getCodeBase().getHost(),
                          getParameter("loginName"),
                          getParameter("password"));
    // Wait for the loggedin() event to enter the place
  }
      
  /**
   * Login event. 
   */
  public void loggedIn(LoginEvent event)
  {
    String msg  = "Logged In";
    m_textArea.setText(msg);
  }
        
  /**
   * Logout event
   */
  public void loggedOut(LoginEvent event)
  {
    String msg  = "Logged Out";
    m_textArea.setText(msg);
  }
        
  /**
   * Returns the applet's insets. Creates 5 pixel margin around 
   * the applet. 
   */
  public Insets getInsets()
  {
    return new Insets(5, 5, 5, 5);
  }
      
  /**
   * Selection changed in the directory list. 
   */
  public void selectionChanged(DirectoryListViewEvent event)
  {
    String msg = "**** Selection Changed ****\n";
                                   
    Vector v = event.getSelectedNodes();
    Enumeration e = v.elements();
    while(e.hasMoreElements())
    {
      msg += ((STObject) e.nextElement()).getName() + "\n";
    }
                
    m_textArea.setText(msg);
  }

  /**
   * User or Group double clicked in the directory's list. 
   */
  public void nodeDoubleClicked(DirectoryListViewEvent event)
  {
    String msg = "**** Node Double Clicked ****\n";
    msg += event.getDoubleClickedNode().getName();
    m_textArea.setText(msg);
  }    
              
  /**
   * Applet destroyed. Logout of Sametime.
   */
  public void destroy()
  {
    CommunityService comm = (CommunityService)
           m_session.getCompApi(CommunityService.COMP_NAME);
    comm.logout();
                    
    m_session.stop();
    m_session.unloadSession();        
  }
}
