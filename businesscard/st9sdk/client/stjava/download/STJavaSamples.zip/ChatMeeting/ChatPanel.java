/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.applet.*;

import com.lotus.sametime.core.types.*;
import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.community.*;
import com.lotus.sametime.places.*;
import com.lotus.sametime.guiutils.chat.*;

public class ChatPanel extends Panel implements	ActionListener
{ 
  private STSession m_session;
  private Place m_place;

  private AppletContext m_context;

  private ChatArea m_chatTranscript;
  private TextField m_txtField;	
  private Font m_font;
  private Button m_btnSend;
  private Panel m_sendPanel;

  /**
   * Chat panel constructor.
   */
  public ChatPanel(STSession session, AppletContext context)
  {
    m_session = session;
    m_context = context;
    
    init();
  }
  
  /** 
   * Bind the chat panel to a specific place.
   */
  public void bindToPlace(Place place)
  {
    m_place = place;
    MyselfInPlace me = m_place.getMyselfInPlace();
    me.addMyMsgListener(new MyMsgEventsListener());
  }

  /** 
   * Layout the chat panel UI.
   */
  private void init()
  {  
    setLayout(new BorderLayout());
        
    m_font = new Font("Dialog",Font.PLAIN ,12);
    m_chatTranscript = new ChatArea(
                          1000,  //chatarea buffer capacity
                          m_font, 
                          17);   //max chat trans name width
    m_chatTranscript.addChatAreaListener(
                       new ChatAreaEventsListener());
		
    m_sendPanel = new Panel();
    m_sendPanel.setLayout(new BorderLayout());
		
    m_btnSend = new Button("Send");
    m_btnSend.addActionListener (this);
    m_sendPanel.add("East", m_btnSend);
       
    m_txtField = new TextField();
    m_txtField.addKeyListener(new TextFieldEventsListener());
    m_txtField.setBackground(Color.white);
    
    m_sendPanel.add("Center", m_txtField);
		
    add("Center", m_chatTranscript);
    add("South", m_sendPanel);     
  }   

  /**
   * Send the text in the msg parameter to the section.
   */
  public void sendText(String msg)
  {
    if (m_place != null)
    {
      Section mySection = m_place.getMySection();
      mySection.sendText(msg);
      m_txtField.requestFocus();
    }
  }
	
  /**
   * Send button pressed.
   */
  public void actionPerformed(ActionEvent event)
  {
    if (event.getSource() == m_btnSend)
    {
      String msg  = m_txtField.getText();
      m_txtField.setText("");
      sendText(msg);
    }
  }
	
  /**
   * Respond to text received event and display it.
   */
  class MyMsgEventsListener extends MyMsgAdapter
  {
    public void textReceived(MyselfEvent event)
    {
      PlaceMember sender = event.getSender();
      String text = event.getText();
      			
      if (!(sender instanceof UserInPlace))
        return;
      		  
      UserInPlace userSender = (UserInPlace)sender;
      CommunityService commService = 
        (CommunityService)m_session.
                getCompApi(CommunityService.COMP_NAME);
      boolean myText = (commService.getLogin().
        getMyUserInstance().getLoginId().
                      equals(userSender.getLoginId()));
      String userName = userSender.getName();
      		    
      m_chatTranscript.write(userName, text, 
              (myText? Color.blue: Color.black ));
    }
  }
   
  /**
   * Respond to the URL clicked event.
   */
  class ChatAreaEventsListener extends ChatAreaAdapter
  {
    public void chatURLClicked(ChatAreaEvent event)
    {
      try {
        String url = event.getURL();
        if (url.indexOf("//") == -1)
          url = "http://" + url;
        m_context.showDocument(new URL(url), "_blank");
      }
      catch(MalformedURLException mue)
      {
        mue.printStackTrace();
      }
  	}
  }
		
  /**
   * Receive the text submit event and pass it on.
   */
  class TextFieldEventsListener extends KeyAdapter 
  {
    public void keyPressed(KeyEvent key)
    {
      if (key.getKeyCode() == key.VK_ENTER)
      {
        sendText(m_txtField.getText());
        m_txtField.setText("");
      }
    }
  }
}
