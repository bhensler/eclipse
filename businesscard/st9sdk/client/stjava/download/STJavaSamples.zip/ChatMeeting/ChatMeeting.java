/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.applet.*;
import java.awt.image.*;
import java.awt.event.*;

import com.lotus.sametime.core.comparch.*;
import com.lotus.sametime.core.constants.*;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.community.*;
import com.lotus.sametime.places.*;
import com.lotus.sametime.awarenessui.*;
import com.lotus.sametime.awarenessui.placelist.*;

/** 
 * Meeting Applet sample showing how to create a chat only meeting
 */
public class ChatMeeting extends Applet
{
  private STSession m_session;
  private CommunityService m_comm;
  private Place m_place;
  private PlaceAwarenessList m_peopleList;
    
  private ChatPanel m_chatPanel; 
  private Label m_PeopleNumLbl;
  	
  private static int numUsersInPlace = 0;
	
  /** 
   * Initialize the applet. Create the session, load and start 
   * the components.
   */
  public void init()
  {
    try
    {
      m_session = new STSession("ChatMeeting " + this);
    }
    catch (DuplicateObjectException	exception)
    {
      exception.printStackTrace();
    }

    m_session.loadAllComponents();   		
    m_session.start();
        
    m_comm = (CommunityService)m_session.getCompApi
                  (CommunityService.COMP_NAME);
    m_comm.addLoginListener(new CommunityEventsListener());
    
    String community = getCodeBase().getHost().toString();
    String loginName = getParameter("loginName");
    String password = getParameter("password");
    m_comm.loginByPassword(community, loginName, password); 
  }
	
  /** 
   * Enter the place the meeting will take place in.
   */
  public void enterPlace()
  {
    PlacesService placesService = 
      (PlacesService)m_session.getCompApi(PlacesService.COMP_NAME);
    
    m_place = placesService.createPlace(	
                    getParameter("placeName"), // place unique name 
                    getParameter("placeName"), // place display name 
                    EncLevel.ENC_LEVEL_DONT_CARE, // encryption level
                    0,                            // place type
                    PlacesConstants.PLACE_PUBLISH_DONT_CARE);
    
    m_place.addPlaceListener(new PlaceEventsListener());
    m_place.enter();
  }
	
  /** 
   * Layout the applet UI.
   */
  protected void layoutAppletUI()
  {
    removeAll();
    this.setBackground(new Color(0xFFcc00));
    setLayout(new BorderLayout(10,0));
      	
    Panel eastPnl = new Panel();
    eastPnl.setLayout(new BorderLayout());
      		
    Panel NPanel = new Panel(new BorderLayout());
    Panel peopleHerePnl = new Panel();
    peopleHerePnl.setLayout(new FlowLayout(FlowLayout.LEFT));
      		
    Label PeopleHereLbl = new Label("People Here:");
    PeopleHereLbl.setFont(new Font("Dialog",Font.PLAIN,14));
    peopleHerePnl.add(PeopleHereLbl);

    m_PeopleNumLbl = new Label("0");
    m_PeopleNumLbl.setFont(new Font("Dialog",Font.PLAIN,14));
    peopleHerePnl.add(m_PeopleNumLbl);
      		
    NPanel.add(peopleHerePnl, BorderLayout.NORTH);
      		
    m_peopleList = new PlaceAwarenessList(m_session, true);  													
    m_peopleList.addAwarenessViewListener(
                        new ParticipantListListener());

    eastPnl.add(NPanel,BorderLayout.NORTH);
    eastPnl.add(m_peopleList,BorderLayout.CENTER);
      	      	
    Panel chatPnl = new Panel();
    chatPnl.setLayout(new BorderLayout());
      		
    Panel chatLblPnl = new Panel(new FlowLayout(FlowLayout.LEFT));
    Label chatLbl = new Label("Place: " + 
                           getParameter("placeName"), Label.LEFT);
    chatLbl.setFont(new Font("Dialog",Font.PLAIN,14));
    chatLblPnl.add(chatLbl);
    chatPnl.add(chatLblPnl,BorderLayout.NORTH);
      		
    m_chatPanel = new ChatPanel(m_session, getAppletContext());
    chatPnl.add(m_chatPanel,BorderLayout.CENTER);
      		
    add(chatPnl,BorderLayout.CENTER);
    add(eastPnl, BorderLayout.EAST);
      		
    validate();
  }
	
  /** 
   * A listener for loggedIn/loggedOut events.
   */
  class CommunityEventsListener implements LoginListener
  {
    public void loggedIn(LoginEvent event)
    {
      layoutAppletUI();
      enterPlace();
    }

    public void loggedOut(LoginEvent event)
    {
    }	
  }
  
  /** 
   * A listener for place events.
   */
  class PlaceEventsListener extends PlaceAdapter
  {    public void entered(PlaceEvent event)
    {
      m_peopleList.bindToSection(m_place.getMySection());
      m_chatPanel.bindToPlace(event.getPlace());
    }		
  }
	  
  /** 
   * A listener for participant list events.
   */
  class ParticipantListListener extends AwarenessViewAdapter
  {
    boolean firstTime = true;
      		    public void usersAdded(AwarenessViewEvent event)
    {      if (firstTime)
      {
        firstTime = false;        numUsersInPlace = event.getUsers().length;       }      else numUsersInPlace++;              
      setLabel(numUsersInPlace);			
    }
    public void usersRemoved(AwarenessViewEvent event)
    {      numUsersInPlace--;
      setLabel(numUsersInPlace);				
    }      		    private void setLabel(int numOfPeople)    {
      m_PeopleNumLbl.setText(String.valueOf(numOfPeople));
      m_PeopleNumLbl.validate();    }
  }
  
  /** 
   * Applet destroyed. Logout, stop and unload the session.
   */
  public void destroy()
  {
    m_comm.logout();
    m_session.stop();
    m_session.unloadSession();
  }  
}

