/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.net.URL;
	
/**
 * Panel for diplaying an image.
 */
class ImagePanel extends Panel
{
    //images counter, require for the MediaTracker.
	static int m_imageNum = 1;
    
    //the image to be shown in this panel
	Image m_image = null;
    
    /**
	 * Constructor
	 * 
	 * @param            url The location of the image.
	 */
	public ImagePanel(URL url)
	{
		m_image  = Toolkit.getDefaultToolkit().getImage(url);
		MediaTracker tracker = new MediaTracker(this);
		tracker.addImage(m_image,m_imageNum++);
		try
		{
			tracker.waitForAll();
		}
		catch(InterruptedException e)
		{
        }
	}
	
    
	/**
	 * Paint the image in the center of the panel.
	 */
	public void paint(Graphics g) 
	{
		int xPos = (this.WIDTH/2 + m_image.getWidth(this)/2) ;
		int yPos = (this.HEIGHT/2 - m_image.getHeight(this)/2) ;
		g.drawImage(m_image, xPos, 0, this);
	}
	
	
    /**
	 * Gets the minimum size for the panel.
	 * 
	 * @return           Dimension of minimum size.
	 */  
	public Dimension getMinimumSize()
	{
		return new Dimension(m_image.getWidth(this),
							 m_image.getHeight(this));
	}

	/**
	 * Gets the preferred size for the panel.
	 * 
	 * @return           Dimension of preferred size.
	 */  
	public Dimension getPreferredSize()
	{
		return getMinimumSize();
	}
}
