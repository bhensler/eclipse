/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.applet.*;
import java.util.*;
import java.net.URL;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.community.*;
import com.lotus.sametime.chatui.ChatUI;
import com.lotus.sametime.chatui.MeetingListener;
import com.lotus.sametime.chatui.MeetingInfo;

/**
 * Sample applet that displays a simple buddy list in a popup frame.
 */
public class BuddyListApplet extends Applet
    implements LoginListener, MeetingListener
{
  private STSession m_session;
  private CommunityService m_comm;
  private BuddyListFrame m_frame;
    
  /**
   * Applet initialized. Create the session, load all components,
   * start the session and then login.
   */
  public void init()
  {
    try
    {
      m_session = new STSession("BuddyListApplet " + this);
      m_session.loadAllComponents();
      m_session.start();
            
      ChatUI chatui = (ChatUI)m_session.getCompApi(ChatUI.COMP_NAME);
      chatui.addMeetingListener(this);
      
      m_frame = new BuddyListFrame(m_session);
      login();
    }
    catch(DuplicateObjectException e)
    {
      e.printStackTrace();
    }
  }
    
  /**
   * Login to the community using the user name and password 
   * parameters from the html.
   */
  private void login()
  {
    m_comm = (CommunityService)
        m_session.getCompApi(CommunityService.COMP_NAME);
    m_comm.addLoginListener(this);     
	  
    m_comm.loginByPassword(getCodeBase().getHost(),
                         getParameter("loginName"),
                         getParameter("password"));     
    
  }
    
  /**
   * Logged in event. Create the buddy list frame and show it.
   */
  public void loggedIn(LoginEvent evt)
  {
    m_frame.setVisible(true);
  }

  /**
   * Launch meeting event. Open a browser at the specified URL.
   */
  public void launchMeeting(MeetingInfo meetingInfo, URL url)
  {
    AppletContext context = getAppletContext();
    context.showDocument(url, "_blank");
  }
	
  /**
   * Meeting creation failed event.
   */
  public void meetingCreationFailed(MeetingInfo meetingInfo, 
                                    int reason)
  {
    System.err.println("Create meeting failed reason = " + reason);
  }
  
  /**
   * Logged out event. Hide the buddy list frame. Leave default
   * behavior which will display a dialog box. 
   */
  public void loggedOut(LoginEvent event)
  {
    if (m_frame != null)
      m_frame.setVisible(false);
  }

  /**
   * Applet destroyed. Logout, stop and unload the session.
   */
  public void destroy()
  {
    m_comm.logout();
    m_session.stop();
    m_session.unloadSession();
    
    m_frame.dispose();
  }
}
