/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.applet.*;
import java.util.*;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.community.*;

/**
 * Sample Sametime Hello World applet.
 */
public class HelloWorldApplet extends Applet
{
  private STSession m_session;
  private CommunityService m_comm;
	
  /**
   * Applet initalized. Create the session, load all components,
   * start the session and then login.
   */
  public void init()
  {
    try
    {
      m_session = new STSession("HelloWorldApplet " + this);            
      m_session.loadAllComponents();
      m_session.start();
      m_comm = (CommunityService)
                m_session.getCompApi(CommunityService.COMP_NAME);
      m_comm.loginByPassword(getCodeBase().getHost().toString(),
                           getParameter("loginName"),
                           getParameter("password"));
	  }
    catch(DuplicateObjectException e)
    {
      e.printStackTrace();
    }
  }    
  
  /**
   * Prints "Hello Sametime" to the applet area. 
   */
  public void paint(Graphics g)
  {
    Font f = new Font(g.getFont().getName(), Font.BOLD, 20);
    g.setFont(f);
    g.setColor(Color.black);
    g.drawString("Hello Sametime", 30, 30);
  }

  /**
   * Applet destroyed. Logout, stop and unload the session.
   */
  public void destroy()
  {
    m_comm.logout();
    m_session.stop();
    m_session.unloadSession();
  }
}
