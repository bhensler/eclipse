/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.community.*;
import com.lotus.sametime.commui.*;

/**
 * Add Dialog Sample.
 */
public class AddDialogApplet extends Applet 
  implements LoginListener, ResolveViewListener, ActionListener
{
  /**
   * Our session.
   */
  private STSession m_session;
      
  /**
   * Text area for displaying messages.
   */
  private TextArea m_textArea;
      
  /**
   * String message displayed within the text area.
   */
  private StringBuffer m_msg = new StringBuffer();
      
  /**
   * The entry point for the applet. 
   */
  public void init()
  {
    try
    {
      // generate a new session with a unique name
      m_session = new STSession("AddDialog Applet " + this);
                    
      // Call the session to load all available components 
      m_session.loadAllComponents();
      m_session.start();
                    
      setLayout(new BorderLayout());
      Panel btnsPanel = new Panel(new GridBagLayout());
                    
      Button openDialog = new Button("Open Add Dialog");
      openDialog.addActionListener(this);
      btnsPanel.add(openDialog);
      add(btnsPanel, BorderLayout.NORTH);
                    
      m_textArea = new TextArea();
      add(m_textArea, BorderLayout.CENTER);
                    
      // login to the community
      login();
    }
    catch(DuplicateObjectException e)
    {
      // This exception is thrown if an STSession with the 
      // same name has already been created.
      e.printStackTrace();
    }                 
  }
    
  /**
   * Login to the community using the user name and password
   * parameters from the html.
   */
  private void login()
  {
    // get a reference to the community service. We use the session 
    // object which contains a reference to all the components that 
    // were loaded to get a reference to the community service. 
    CommunityService comm = (CommunityService)
        m_session.getCompApi(CommunityService.COMP_NAME);
              
    // register a listener to the login/logout events.
    comm.addLoginListener(this);
              
    // login to the community
    comm.loginByPassword(getCodeBase().getHost(),
                         getParameter("loginName"),
                         getParameter("password"));
  }
      
  /**
   * Login event. 
   */
  public void loggedIn(LoginEvent event)
  {
    m_msg.append("Logged In");
    m_textArea.setText(m_msg.toString());
  }
      
  /**
   * Logout event
   */
  public void loggedOut(LoginEvent event)
  {
    m_msg.append("Logged Out");
    m_textArea.setText(m_msg.toString());
  }
      
  /**
   * Notification of a successful resolve operation.
   */
  public void resolved(ResolveViewEvent event)
  {
    m_msg.append("**** Resolved ****\n");
    // when choosing names from Address Book, event.getResolvedName() = null.
    m_msg.append(((event.getResolvedName() == null)? 
                  event.getUser().getName():event.getResolvedName()) +
                  " : " +  
                  event.getUser().getName() + "\n");
    m_textArea.setText(m_msg.toString());
  }
      
  /**
   * Notification of a failed resolve operation.
   */
  public void resolveFailed(ResolveViewEvent event)
  {
    m_msg.append("**** Resolved Failed****\n");
    m_msg.append(event.getResolvedName() + ", Reason:" + 
                 Integer.toHexString(event.getReason()) + "\n");
    m_textArea.setText(m_msg.toString());
  }
            
  /**
   * Action Performed. The button was clicked open the dialog. 
   */
  public void actionPerformed(ActionEvent e)
  {
    Container parent = getParent();
    while (!(parent instanceof Frame)) {
		parent = parent.getParent();
    }
    AddDialog d  = new AddDialog((Frame)parent, m_session, "Select Users");
    d.addResolveViewListener(this);
    d.setVisible(true);
  }
}
