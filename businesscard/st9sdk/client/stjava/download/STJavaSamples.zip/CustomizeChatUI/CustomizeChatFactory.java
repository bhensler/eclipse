/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.applet.*;
import java.net.*;
import java.text.DateFormat; 

import com.lotus.sametime.chatui.*;
import com.lotus.sametime.chatui.invitation.*;
import com.lotus.sametime.core.constants.*;
import com.lotus.sametime.core.comparch.*;
import com.lotus.sametime.core.types.*;
import com.lotus.sametime.resourceloader.ResourceLoaderService;

/**
 * This class overides the DefaultChatFactory to customize the look of the
 * chat/conf frame by adding: logo on top and bottom, shortcut buttons and a
 * new help menu item.
 */
public class CustomizeChatFactory extends DefaultChatFactory 
                                  implements TextModifier
{
	/**
	 * Time stamp option check box.
	 */
	Checkbox m_addTime;
	
	/**
     * The running applet.
     */
    Applet m_applet;
	
	
    /**
     * The CustomizeChatFactory Constructor.
     * 
     * @param            STSession session
     * @param            Applet The running applet.
     */
    public CustomizeChatFactory(STSession session,Applet applet)
    {
        super(session);
        m_applet = applet;
	}
    
	
    /**
     * The Text submited event.
     * If the time stamp option is on, the message will be modified to include
     * the time stamp.
     * 
     * @param            String The original message.
     * @return           Strint the modified message
     */
    public String TextSubmitted(String text)
    {
		if(m_addTime.getState())
		{
			text = getTimeStamp() + text;
		}		
        return text;
	}
    
    
    /**
	 * Get the object that serves as the TextModifier for the specified
	 * ChatFrame. In our case a single modifier serves all frames.
	 * 
	 * @return           TextModifier object that parse the text.
	 */
	public TextModifier getTextModifier(ChatFrame frame)
    {
        return this;
    }
    
     
    /**
     * Called by the ChatFrame to get customized user panels.
     * The ChatFrame will call on this method 3 times, each time specifiying a
     * different panel position according to the constants defined.
     * 
     * @param            panelPosition One of the fixed positions defined by
     *                   DefaultChatFactory.TOP_PANEL
     *                   DefaultChatFactory.CENTER_PANEL,
     *                   DefaultChatFactory.BOTTOM_PANEL
     * @param            frame The chat frame that the panel will be embedded in.
     * @see              DefaultChatFactory#TOP_PANEL
     * @see              DefaultChatFactory#CENTER_PANEL
     * @see              DefaultChatFactory#BOTTOM_PANEL
     */
    public Panel getCustomizedPanels(int panelPosition, 
                               ChatFrame frame)
    {
        if (panelPosition == TOP_PANEL)
            return createLogoPanel("logo.gif");
        
        if (panelPosition == CENTER_PANEL)
            return ShortcutButtons(frame);
        
        if (panelPosition == BOTTOM_PANEL)
            return createLogoPanel("logo.gif");
        
        return null;
    }
	
	
    /**
     * Called by the ChatFrame to get customized menu items. In this sample we
     * add a "about" menu item to the "help" menu.
     * 
     * @param            MenuBar The ChatFrame's MenuBar that the items should be
     *                   added to.
     */
    public void getCustomizedMenu(MenuBar mb)
    {
        //Create help menu and add "about" MenuItem
        Menu helpMenu = new Menu("Help");
        
        MenuItem about = new MenuItem("About");
        about.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                try
                {
                    m_applet.getAppletContext().showDocument
                        (new URL ("http://www.lotus.com/home.nsf/welcome/sametime"),
                        "target");
                }
                catch (MalformedURLException e)
                {
                    e.printStackTrace();
                }
             }
         });
        
        helpMenu.add(about);
        mb.add(helpMenu);
    }
    
    //
    //helper
    //
   
	/**
     * Create the panel that contains the shortcut buttons, and the add time
     * stemp check box.
     */
    private Panel ShortcutButtons(ChatFrame frame)
    {
        final ChatFrame chatFrame = frame;
        Panel centerPanel =  new Panel(new BorderLayout(4,0));
     
        //Create shortcut buttons and add action listener
	    Button coffee = new Button("Coffee");
        coffee.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
		        String message = "I am in a coffee break";
			    if(CustomizeChatFactory.this.m_addTime.getState())
			    {
			    	message = getTimeStamp() + message;
			    }
            chatFrame.getChatModel().sendMessage(message);
            }
        });
     
        Button meeting = new Button("In Meeting");
        meeting.addActionListener(new ActionListener()
        {
           public void actionPerformed(ActionEvent event)
           {
		        String message = "I am in a meeting now";
		    	if(CustomizeChatFactory.this.m_addTime.getState())
		    	{
		    		message = getTimeStamp() + message;
		    	}
                chatFrame.getChatModel().sendMessage(message);
            }
         });
        
        //Add the buttons into panel
        Panel buttonsPnl =new Panel(new FlowLayout(FlowLayout.LEFT));
	    buttonsPnl.add(coffee);
	    buttonsPnl.add(meeting);
        
        //Add the time stamp check box
	    m_addTime  = new Checkbox("Add Time Stamp");
	    m_addTime.setState(true);
        
	    Panel buttonsPanel = new Panel(new BorderLayout());
	    
        //Add the buttons and the check box to the center panel
	    centerPanel.add(buttonsPnl,BorderLayout.WEST);
	    centerPanel.add(m_addTime, BorderLayout.EAST);
   
        return centerPanel;
    }
    
    
    /**
     * Generate a string representing the current time.
     */
    private String getTimeStamp()
    {
		Date m_date = new Date();
        int hours =  m_date.getHours();
        int minutes =  m_date.getMinutes();
        if (minutes < 10)
        {
            return hours + ":" + "0" + minutes+ " ";
        }
        else
        {
            return (""+hours + ":" + minutes+ " ");
        }
    }
    
	
    /**
     * Create the logo panel used in the top and bottom panels.
     */
    private Panel createLogoPanel(String logo)
	{
		Panel  p = new ImagePanel(getLogoURL(logo));
		p.setBackground(new Color(0xFFcc00));
		return p;
	}
    
    
    /**
     * Gets the logo's location.
     */
    private URL getLogoURL(String logo)
    {
       URL url = null; 
       try
       {
           url = new URL(m_applet.getCodeBase(), logo);      
       }
       catch(MalformedURLException e)
       {
            e.printStackTrace(); 
       }
       
       
       return url;
    } 
}
