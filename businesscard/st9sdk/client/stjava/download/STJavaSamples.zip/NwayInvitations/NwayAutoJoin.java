/*
 * Licensed Materials - Property of IBM
 *
 * L-MCOS-96LQPJ
 *
 * (C) Copyright IBM Corp. 2002, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

import java.util.Calendar;

import com.lotus.sametime.chat.invitation.*;
import com.lotus.sametime.community.CommunityService;
import com.lotus.sametime.community.LoginEvent;
import com.lotus.sametime.community.LoginListener;
import com.lotus.sametime.core.comparch.DuplicateObjectException;
import com.lotus.sametime.core.comparch.STSession;
import com.lotus.sametime.places.PlacesConstants;

/**
 * This sample will automatically accept an invitation to an n-way chat.
 *
 * Once accepted, it will create an NwayChatSample based on the invitation.
 *
 * NOTE: This sample block waits on things like login, service available events, etc. just for simplicity.
 */
public class NwayAutoJoin implements LoginListener, InvitationListener
{
    private STSession m_session = null;
    private CommunityService m_commSvc = null;
    private String m_host = "";
    private String m_user = "";
    private String m_password = "";
    private boolean m_loggedIn = false;

    public NwayAutoJoin(String host, String user, String password)
    {
        m_host = host;
        m_user = user;
        m_password = password;

        try
        {
            m_session = new STSession("NwayAutoJoin " + this);
            m_session.loadSemanticComponents();
            m_session.start();

            InvitationManager invitationManager = new InvitationManager(m_session);
            invitationManager.setListener(this);

            login();
            while (!m_loggedIn)
            {
                System.out.print("");
            }
        }
        catch(DuplicateObjectException e)
        {
            e.printStackTrace();
        }
    }

    private void login()
    {
        m_commSvc = (CommunityService) m_session.getCompApi(CommunityService.COMP_NAME);
        m_commSvc.addLoginListener(this);
        m_commSvc.loginByPassword(m_host, m_user, m_password.toCharArray());
    }

    public void loggedIn(LoginEvent event)
    {
        m_loggedIn = true;
        System.out.println("Logged In at: " + Calendar.getInstance().getTime().toString());
    }

    public void loggedOut(LoginEvent event)
    {
        m_loggedIn = false;
        System.out.println("Logged Out: 0x" + Integer.toHexString(event.getReason()) + " at: " + Calendar.getInstance().getTime().toString());
    }

    public void invitedToMeeting(Invitation invitation)
    {
    	System.out.println("Invited to meeting from: "
    			+ invitation.getInviter().getDisplayName()
    			+ " - invitation text: "
    			+ invitation.getInviteMessage());

    	// Accept the invitation
    	invitation.accept();

    	// Create a new instance of the NwayChatSample based on the information in this invitation.
    	// Note: In this case we want to join an existing place.
    	new NwayChatSample(m_session,
    			invitation.getMeetingInfo().getPlaceName(),
    			invitation.getMeetingInfo().getDisplayName(),
    			invitation.getMeetingInfo().getPassword(),
    			PlacesConstants.PLACE_CREATION_JOIN);
    }

	public static void main(String[] args)
	{
    	if (args.length < 3)
    	{
            System.out.println("Wrong number of arguments.  Please supply servername, user amd password");
            System.out.println("Example: java NwayAutoJoin sametime.acme.com testUser testPassword");
        }
        else
        {
            String server = args[0];
            String user = args[1];
            String pwd = args[2];
        	new NwayAutoJoin(server, user, pwd);
        }
	}
}